# SUPERSEDED

Family Uni V4 CP DETF diamond is **deleted**. Do not restore this package.

Uni V4 v1 DETF product law:

- Package: `contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/` (`UniswapV4DetfDFPkg` / `IUniswapV4Detf`)
- [`DETF_INSTANCE_IO_ROUTING_PRD.md`](../../../../../../DETF_INSTANCE_IO_ROUTING_PRD.md) §16
- [`UNIFIED_DETF_DEPRECATION_TEST_COVERAGE_PRD.md`](../../../../../../UNIFIED_DETF_DEPRECATION_TEST_COVERAGE_PRD.md)

CP buffer **hook** remains under `contracts/hooks/uniswap/v4/standardExchange/constantProduct/single/`.
