// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {UniswapV4DetfTarget} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4DetfTarget.sol";

/// @notice Exchange entrypoints for the universal DETF diamond.
abstract contract UniswapV4DetfExchangeTarget is UniswapV4DetfTarget {
    /// @notice Joins accepted capital and mints the user DETF allocation subject to the output minimum.
    function mint(
        IERC20 tokenIn,
        uint256 amountIn,
        uint256 minUserDetf,
        address recipient,
        bool pretransferred,
        uint256 deadline
    ) external returns (uint256 userDetf) {
        return _entryMint(tokenIn, amountIn, minUserDetf, recipient, pretransferred, deadline);
    }

    /// @notice Executes an exact-input mint, burn, or DETF-to-claim route on the diamond.
    function exchangeIn(
        IERC20 tokenIn_,
        uint256 amountIn_,
        IERC20 tokenOut_,
        uint256 minAmountOut_,
        address recipient_,
        bool pretransferred_,
        uint256 deadline_
    ) external returns (uint256 amountOut_) {
        return _entryExchangeIn(tokenIn_, amountIn_, tokenOut_, minAmountOut_, recipient_, pretransferred_, deadline_);
    }

    /// @notice Burns DETF and pays the configured output token subject to the output minimum.
    function burn(uint256 detfIn, IERC20 tokenOut, uint256 minAmountOut, address recipient, uint256 deadline)
        external
        returns (uint256 amountOut)
    {
        return _entryBurn(detfIn, tokenOut, minAmountOut, recipient, deadline);
    }
}
