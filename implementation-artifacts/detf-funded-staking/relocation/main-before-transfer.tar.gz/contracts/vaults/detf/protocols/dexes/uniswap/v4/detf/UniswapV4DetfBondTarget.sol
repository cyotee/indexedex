// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {UniswapV4DetfTarget} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4DetfTarget.sol";

/// @notice Bond entrypoints for the universal DETF diamond.
abstract contract UniswapV4DetfBondTarget is UniswapV4DetfTarget {
    /// @notice Joins capital and opens a time-locked NFT with principal priced at pre-join NAV.
    /// @dev Returns physical LP as shares; the NFT credits converted original-share principal.
    function bond(
        IERC20 tokenIn,
        uint256 amountIn,
        uint256 lockDuration,
        address recipient,
        bool pretransferred,
        uint256 deadline
    ) external returns (uint256 tokenId, uint256 shares) {
        return _entryBond(tokenIn, amountIn, lockDuration, recipient, pretransferred, deadline);
    }

    /// @notice Closes the caller's mature bond and pays its configured non-DETF outputs.
    function closeBondMature(uint256 tokenId, uint256[] calldata minAmountsOut, address recipient, uint256 deadline)
        external
        returns (uint256[] memory amountsOut)
    {
        return _entryCloseBondMature(tokenId, minAmountsOut, recipient, deadline);
    }
}
