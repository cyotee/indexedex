// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IDETFNFTVault} from "contracts/interfaces/IDETFNFTVault.sol";
import {IUniswapV4Detf} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/interfaces/IUniswapV4Detf.sol";
import {ThresholdMode} from "contracts/vaults/detf/common/core/DETFThresholdPolicy.sol";
import {UniswapV4DetfTarget} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4DetfTarget.sol";

/// @notice Query entrypoints for the universal DETF diamond.
abstract contract UniswapV4DetfQueryTarget is UniswapV4DetfTarget {
    /// @notice Returns the configured reserve hook.
    function hook() external view returns (address) {
        return _entryHook();
    }

    /// @notice Returns the hook address used as the reserve LP token.
    function reservePool() external view returns (address) {
        return _entryReservePool();
    }

    /// @notice Reports whether the first bond has activated the reserve.
    function isReserveLive() external view returns (bool) {
        return _entryIsReserveLive();
    }

    /// @notice Reports whether both child NFT and claim-token vaults are deployed.
    function isReserveWired() external view returns (bool) {
        return _entryIsReserveWired();
    }

    /// @notice Returns the immutable token-to-vault routes accepted for minting.
    function mintRoutes() external view returns (IUniswapV4Detf.IoRoute[] memory) {
        return _entryMintRoutes();
    }

    /// @notice Returns the immutable token-to-vault routes accepted for burning.
    function burnRoutes() external view returns (IUniswapV4Detf.IoRoute[] memory) {
        return _entryBurnRoutes();
    }

    /// @notice Returns the immutable token-to-vault routes accepted for bonding.
    function bondRoutes() external view returns (IUniswapV4Detf.IoRoute[] memory) {
        return _entryBondRoutes();
    }

    /// @notice Returns the immutable routes used to pay mature bond closes.
    function closeRoutes() external view returns (IUniswapV4Detf.IoRoute[] memory) {
        return _entryCloseRoutes();
    }

    /// @notice Returns the immutable token-to-vault routes accepted for donations.
    function donateRoutes() external view returns (IUniswapV4Detf.IoRoute[] memory) {
        return _entryDonateRoutes();
    }

    /// @notice Returns the configured default or custom mint-route mode.
    function mintRouteMode() external view returns (IUniswapV4Detf.RouteTableMode) {
        return _entryMintRouteMode();
    }

    /// @notice Returns the configured default or custom burn-route mode.
    function burnRouteMode() external view returns (IUniswapV4Detf.RouteTableMode) {
        return _entryBurnRouteMode();
    }

    /// @notice Returns the configured default or custom bond-route mode.
    function bondRouteMode() external view returns (IUniswapV4Detf.RouteTableMode) {
        return _entryBondRouteMode();
    }

    /// @notice Returns the configured default or custom mature-close mode.
    function closeRouteMode() external view returns (IUniswapV4Detf.RouteTableMode) {
        return _entryCloseRouteMode();
    }

    /// @notice Returns the configured default or custom donation-route mode.
    function donateRouteMode() external view returns (IUniswapV4Detf.RouteTableMode) {
        return _entryDonateRouteMode();
    }

    /// @notice Returns the creation rates for the configured non-DETF reserve legs.
    function creationPairPerDetfWad() external view returns (uint256[] memory) {
        return _entryCreationPairPerDetfWad();
    }

    /// @notice Returns the opening rates used to size first-bond reserve legs.
    function openingPairPerDetfWad() external view returns (uint256[] memory) {
        return _entryOpeningPairPerDetfWad();
    }

    /// @notice Returns the stored mint threshold in WAD precision.
    function mintThreshold() external view returns (uint256) {
        return _entryMintThreshold();
    }

    /// @notice Returns the stored burn threshold in WAD precision.
    function burnThreshold() external view returns (uint256) {
        return _entryBurnThreshold();
    }

    /// @notice Returns whether threshold policy is open or price-gated.
    function thresholdMode() external view returns (ThresholdMode) {
        return _entryThresholdMode();
    }

    /// @notice Quotes the current synthetic DETF price from the configured hook.
    function syntheticPrice() external view returns (uint256) {
        return _entrySyntheticPrice();
    }

    /// @notice Quotes the unrealized natural expansion in DETF units.
    function pendingExpansionDetf() external view returns (uint256) {
        return _entryPendingExpansionDetf();
    }

    /// @notice Returns the deployed bond NFT vault address.
    function bondNftVault() external view returns (address) {
        return _entryBondNftVault();
    }

    /// @notice Returns the bond NFT vault through the shared DETF inventory interface.
    function detfNFTVault() external view returns (IDETFNFTVault) {
        return _entryDetfNFTVault();
    }

    /// @notice Returns the deployed rebasing claim-token address.
    function rebasingClaimToken() external view returns (address) {
        return _entryRebasingClaimToken();
    }

    /// @notice Returns all token addresses accepted by the bond route table.
    function acceptedBondTokens() external view returns (address[] memory tokens_) {
        return _entryAcceptedBondTokens();
    }

    /// @notice Reports whether the mint threshold and, when supplied, the token route permit minting.
    function isMintingAllowed() external view returns (bool) {
        return _entryIsMintingAllowed();
    }

    /// @notice Reports whether the mint threshold and, when supplied, the token route permit minting.
    function isMintingAllowed(IERC20 tokenIn) external view returns (bool) {
        return _entryIsMintingAllowed(tokenIn);
    }

    /// @notice Reports whether the burn threshold and, when supplied, the token route permit burning.
    function isBurningAllowed() external view returns (bool) {
        return _entryIsBurningAllowed();
    }

    /// @notice Reports whether the burn threshold and, when supplied, the token route permit burning.
    function isBurningAllowed(IERC20 tokenOut) external view returns (bool) {
        return _entryIsBurningAllowed(tokenOut);
    }

    /// @notice Quotes gross DETF, user DETF, and physical LP for a configured mint input.
    function previewMint(IERC20 tokenIn, uint256 amountIn)
        external
        view
        returns (uint256 grossDetf, uint256 userDetf, uint256 lpOut)
    {
        return _entryPreviewMint(tokenIn, amountIn);
    }

    /// @notice Quotes an input token amount in its configured vault's reserve-pair units.
    function peekPairEq(address vault_, address tokenIn_, uint256 amountIn_) external view returns (uint256) {
        return _entryPeekPairEq(vault_, tokenIn_, amountIn_);
    }

    /// @notice Quotes the configured exact-input exchange route without changing reserve state.
    function previewExchangeIn(IERC20 tokenIn_, uint256 amountIn_, IERC20 tokenOut_)
        external
        view
        returns (uint256 amountOut_)
    {
        return _entryPreviewExchangeIn(tokenIn_, amountIn_, tokenOut_);
    }

    /// @notice Quotes the output token paid for burning the supplied DETF amount.
    function previewBurn(uint256 detfIn, IERC20 tokenOut) external view returns (uint256 amountOut) {
        return _entryPreviewBurn(detfIn, tokenOut);
    }

    /// @notice Quotes the configured output amounts for closing a mature bond.
    function previewCloseBondMature(uint256 tokenId) external view returns (uint256[] memory amountsOut) {
        return _entryPreviewCloseBondMature(tokenId);
    }

    /// @notice Quotes physical reserve LP produced by an accepted donation input.
    function previewJoinDonatedCapital(IERC20 token, uint256 amount) external view returns (uint256 lpOut) {
        return _entryPreviewJoinDonatedCapital(token, amount);
    }

    /// @notice Quotes DETF obtainable by unwinding the supplied physical reserve LP.
    function previewClaimLiquidity(uint256 lpAmount) external view returns (uint256 detfOut) {
        return _entryPreviewClaimLiquidity(lpAmount);
    }
}
