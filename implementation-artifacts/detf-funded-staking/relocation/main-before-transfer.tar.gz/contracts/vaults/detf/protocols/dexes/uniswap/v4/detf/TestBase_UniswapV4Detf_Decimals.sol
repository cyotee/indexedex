// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IFacet} from "@crane/contracts/interfaces/IFacet.sol";
import {ICreate3FactoryProxy} from "@crane/contracts/interfaces/proxies/ICreate3FactoryProxy.sol";
import {IFacetRegistry} from "@crane/contracts/interfaces/IFacetRegistry.sol";
import {IERC165} from "@crane/contracts/interfaces/IERC165.sol";
import {IDiamondLoupe} from "@crane/contracts/interfaces/IDiamondLoupe.sol";
import {IERC8109Introspection} from "@crane/contracts/interfaces/IERC8109Introspection.sol";
import {IPostDeployAccountHook} from "@crane/contracts/interfaces/IPostDeployAccountHook.sol";
import {IDiamondFactoryPackage} from "@crane/contracts/interfaces/IDiamondFactoryPackage.sol";
import {IPoolManager} from "@crane/contracts/protocols/dexes/uniswap/v4/interfaces/IPoolManager.sol";
import {PoolManager} from "@crane/contracts/protocols/dexes/uniswap/v4/PoolManager.sol";
import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IPermit2} from "@crane/contracts/interfaces/protocols/utils/permit2/IPermit2.sol";
import {BetterEfficientHashLib} from "@crane/contracts/utils/BetterEfficientHashLib.sol";
import {ERC721Facet} from "@crane/contracts/tokens/ERC721/ERC721Facet.sol";

import {IVaultRegistryDeployment} from "contracts/interfaces/IVaultRegistryDeployment.sol";
import {IVaultFeeOracleQuery} from "contracts/interfaces/IVaultFeeOracleQuery.sol";
import {IVaultFeeOracleManager} from "contracts/interfaces/IVaultFeeOracleManager.sol";
import {BondTerms} from "contracts/interfaces/VaultFeeTypes.sol";
import {IStandardExchangeIn} from "@crane/contracts/interfaces/IStandardExchangeIn.sol";
import {ThresholdMode} from "contracts/vaults/detf/common/core/DETFThresholdPolicy.sol";
import {DetfComponentFactoryService} from "contracts/vaults/detf/common/factory/DetfComponentFactoryService.sol";
import {DetfFacetFactoryService} from "contracts/vaults/detf/common/factory/DetfFacetFactoryService.sol";
import {DetfPkgFactoryService} from "contracts/vaults/detf/common/factory/DetfPkgFactoryService.sol";
import {IRebasingClaimTokenDFPkg} from "contracts/vaults/detf/common/claimToken/RebasingClaimTokenDFPkg.sol";
import {IUniswapV4DetfBondNFTVaultDFPkg} from
    "contracts/vaults/detf/protocols/dexes/uniswap/v4/bondNft/UniswapV4DetfBondNFTVaultDFPkg.sol";
import {VaultComponentFactoryService} from "contracts/vaults/VaultComponentFactoryService.sol";
import {TestBase_ERC4626StandardExchange} from "contracts/test/bases/TestBase_ERC4626StandardExchange.sol";
import {MintableERC20Decimals} from "contracts/test/stubs/MintableERC20Decimals.sol";
import {SimpleYieldERC4626} from "contracts/test/stubs/SimpleYieldERC4626.sol";
import {
    IUniswapV4HookStagedPairInit
} from "contracts/hooks/uniswap/v4/interfaces/IUniswapV4HookStagedPairInit.sol";
import {
    IUniswapV4HookDiamondPackageCallBackFactory
} from "contracts/hooks/uniswap/v4/factory/interfaces/IUniswapV4HookDiamondPackageCallBackFactory.sol";
import {
    UniswapV4HookDiamondPackageCallBackFactory_FactoryService as HookFactoryService
} from "contracts/hooks/uniswap/v4/factory/UniswapV4HookDiamondPackageCallBackFactory_FactoryService.sol";
import {
    IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage
} from "contracts/hooks/uniswap/v4/standardExchange/constantProduct/single/interfaces/IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage.sol";
import {
    UniswapV4SingleStandardExchangeBufferConstantProductHook_FactoryService as CpHookFactory
} from "contracts/hooks/uniswap/v4/standardExchange/constantProduct/single/UniswapV4SingleStandardExchangeBufferConstantProductHook_FactoryService.sol";
import {
    IUniswapV4DualStandardExchangeBufferConstantProductHookPackage
} from "contracts/hooks/uniswap/v4/standardExchange/dual/interfaces/IUniswapV4DualStandardExchangeBufferConstantProductHookPackage.sol";
import {
    UniswapV4DualStandardExchangeBufferConstantProductHook_FactoryService as DualFactory
} from "contracts/hooks/uniswap/v4/standardExchange/dual/UniswapV4DualStandardExchangeBufferConstantProductHook_FactoryService.sol";
import {IUniswapV4SeBufferHook} from "contracts/hooks/uniswap/v4/interfaces/IUniswapV4SeBufferHook.sol";
import {
    IUniswapV4Detf,
    IUniswapV4DetfDFPkg
} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/interfaces/IUniswapV4Detf.sol";
import {UniswapV4Detf_Facet_FactoryService} from
    "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4Detf_Facet_FactoryService.sol";
import {HookPkgArgsDecimalsLib} from "contracts/test/libs/HookPkgArgsDecimalsLib.sol";
import {UniswapV4Detf_Pkg_FactoryService} from
    "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4Detf_Pkg_FactoryService.sol";

/**
 * @title TestBase_UniswapV4Detf_Decimals
 * @notice CP DETF with combo-decimal pairToken. Does not edit gold TestBase_UniswapV4Detf.
 * @dev pairToken decimals from `_pairDecimals()`. `_rateDecimals()` records the other combo
 *      role; gold CP has one ERC-4626 SE underlying, so this TestBase does not construct a
 *      second non-18 vaultShare. vaultShare / detfToken / rebasingClaimToken / Bond NFT stay 18.
 *      After PoolKey sort, pairToken is still the pair role. First-bond amounts use `_uPair`.
 */
abstract contract TestBase_UniswapV4Detf_Decimals is TestBase_ERC4626StandardExchange {
    using BetterEfficientHashLib for bytes;
    using DetfFacetFactoryService for ICreate3FactoryProxy;
    using DetfPkgFactoryService for ICreate3FactoryProxy;
    using DetfPkgFactoryService for IVaultRegistryDeployment;
    using VaultComponentFactoryService for ICreate3FactoryProxy;

    uint256 internal constant DEFAULT_MIN_LOCK = 30 days;
    uint256 internal constant DEFAULT_MAX_LOCK = 180 days;
    uint256 internal constant DEFAULT_CREATION_PAIR_PER_DETF = 1e18;

    address internal constant PERMIT2_ADDR = 0x000000000022D473030F116dDEE9F6B43aC78BA3;

    MintableERC20Decimals internal pairToken;
    MintableERC20Decimals internal detfDecimalsStub;
    SimpleYieldERC4626 internal pairProtocolVault;
    address internal se;
    IPoolManager internal pm;
    IUniswapV4HookDiamondPackageCallBackFactory internal hookFactory;
    IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage internal hookPkg;
    address internal reserveHook;

    IFacet[5] internal detfProductFacets;
    IFacet internal detfNFTVaultFacet;
    IFacet internal erc721FacetDetf;
    IUniswapV4DetfBondNFTVaultDFPkg internal bondNftVaultPkg;
    IRebasingClaimTokenDFPkg internal rebasingClaimTokenPkg;
    IUniswapV4DetfDFPkg internal detfPkg;

    address internal detf;
    IUniswapV4Detf internal detfInfo;
    IStandardExchangeIn internal detfExchangeIn;
    address internal detfUser = address(0xD37F);

    function _pairDecimals() internal pure virtual returns (uint8);
    function _rateDecimals() internal pure virtual returns (uint8) {
        return 18;
    }

    /// @dev Cached `pairToken.decimals()`. `_uPair` must not `decimals()`-call: that
    ///      consumes `vm.prank` / `vm.expectRevert` when `_uPair` is an argument.
    uint8 internal _cachedPairDecimals;

    function _syncPairDecimals() internal {
        _cachedPairDecimals = _pairDecimals();
        if (address(pairToken) == address(0)) return;
        try pairToken.decimals() returns (uint8 got_) {
            if (got_ != 0) _cachedPairDecimals = got_;
        } catch {}
    }

    function _uPair(uint256 human) internal view returns (uint256) {
        uint8 d_ = _cachedPairDecimals;
        if (d_ == 0) d_ = _pairDecimals();
        return human * (10 ** uint256(d_));
    }

    function _uRate(uint256 human) internal pure returns (uint256) {
        return human * (10 ** uint256(_rateDecimals()));
    }

    /// @dev Fund `who` for a bond of `pairAmount_` native pair units. CP mints pairToken.
    ///      Weighted/orbital/quad hooks mint every external hook pair (skip detfToken).
    ///      Lives on this TestBase (not ProdSe) so Stage11 diamonds do not fork the function.
    function _fundBondLegs(address who, uint256 pairAmount_) internal virtual {
        address hook_ = address(0);
        if (address(detfInfo) != address(0)) {
            hook_ = detfInfo.hook();
        }
        if (hook_ == address(0)) hook_ = reserveHook;
        if (hook_ == address(0) || hook_.code.length == 0) {
            pairToken.mint(who, pairAmount_);
            vm.prank(who);
            IERC20(address(pairToken)).approve(detf, type(uint256).max);
            return;
        }

        uint8 pd_ = _cachedPairDecimals;
        if (pd_ == 0) pd_ = _pairDecimals();
        uint256 human_ = pd_ == 0 ? pairAmount_ : pairAmount_ / (10 ** uint256(pd_));
        if (human_ == 0) human_ = 1;

        address[] memory toks = IUniswapV4SeBufferHook(hook_).tokens();
        bool mintedPair;
        for (uint256 i; i < toks.length; ++i) {
            if (toks[i] == detf) continue;
            uint8 d_ = 18;
            try MintableERC20Decimals(toks[i]).decimals() returns (uint8 got_) {
                d_ = got_;
            } catch {}
            uint256 amt_ = toks[i] == address(pairToken)
                ? pairAmount_
                : (human_ * 2 + 1) * (10 ** uint256(d_));
            _fundBondLeg(toks[i], who, amt_);
            vm.prank(who);
            IERC20(toks[i]).approve(detf, type(uint256).max);
            if (toks[i] == address(pairToken)) mintedPair = true;
        }
        if (!mintedPair) {
            _fundBondLeg(address(pairToken), who, pairAmount_);
            vm.prank(who);
            IERC20(address(pairToken)).approve(detf, type(uint256).max);
        }
    }

    /// @dev Mintable stubs mint. Pons/Morpho TestBases override `_fundBondLegFallback`.
    function _fundBondLeg(address token_, address who, uint256 amt_) internal virtual {
        if (IERC20(token_).balanceOf(who) >= amt_) return;
        try MintableERC20Decimals(token_).mint(who, amt_) {
            if (IERC20(token_).balanceOf(who) >= amt_) return;
        } catch {}
        uint256 have_ = IERC20(token_).balanceOf(who);
        deal(token_, who, have_ + amt_, true);
        if (IERC20(token_).balanceOf(who) >= amt_) return;
        deal(token_, who, have_ + amt_);
        if (IERC20(token_).balanceOf(who) >= amt_) return;
        _fundBondLegFallback(token_, who, amt_);
    }

    function _fundBondLegFallback(address, address, uint256) internal virtual {}

    /// @dev Scale native pair units to 18-dec WAD using the bonded pairToken's decimals.
    function _pairInToJoinWad(uint256 pairAmount_) internal view virtual returns (uint256) {
        uint8 d_ = _cachedPairDecimals;
        if (d_ == 0) d_ = _pairDecimals();
        if (d_ >= 18) return pairAmount_;
        return pairAmount_ * (10 ** (18 - uint256(d_)));
    }

    function setUp() public virtual override {
        TestBase_ERC4626StandardExchange.setUp();
        vm.etch(PERMIT2_ADDR, address(permit2).code);
        permit2 = IPermit2(PERMIT2_ADDR);

        pairToken = new MintableERC20Decimals("Pair", "PAIR", _pairDecimals());
        _syncPairDecimals();
        detfDecimalsStub = new MintableERC20Decimals("DetfStub", "DSTUB", 18);
        pairProtocolVault = new SimpleYieldERC4626(pairToken);
        se = _deployERC4626SE(address(pairProtocolVault));
        pm = IPoolManager(address(new PoolManager(address(this))));

        _deployHookFactoryAndPkg();
        _deployBondNftVaultPkg();
        _deployRebasingClaimTokenPkg();
        _deployDetfPkg();
        _setDefaultBondTerms(DEFAULT_MIN_LOCK, DEFAULT_MAX_LOCK);

        detf = _deployHookThenDetf(_defaultDetfArgs());
        detfInfo = IUniswapV4Detf(detf);
        detfExchangeIn = IStandardExchangeIn(detf);
        _setBondTerms(DEFAULT_MIN_LOCK, DEFAULT_MAX_LOCK);
        _syncPairDecimals();

        pairToken.mint(detfUser, _uPair(10_000_000));
        vm.startPrank(detfUser);
        pairToken.approve(detf, type(uint256).max);
        pairToken.approve(se, type(uint256).max);
        IERC20(se).approve(detf, type(uint256).max);
        vm.stopPrank();
    }

    function _deployHookFactory() internal {
        IFacet hookFlagsFacet = HookFactoryService.deployUniswapV4HookFlagsFacet(create3Factory);
        IFacetRegistry facetReg = IFacetRegistry(address(create3Factory));
        hookFactory = HookFactoryService.deployUniswapV4HookDiamondPackageCallBackFactory(
            create3Factory,
            IUniswapV4HookDiamondPackageCallBackFactory.InitArgs({
                erc165Facet: facetReg.canonicalFacet(type(IERC165).interfaceId),
                diamondLoupeFacet: facetReg.canonicalFacet(type(IDiamondLoupe).interfaceId),
                erc8109IntrospectionFacet: facetReg.canonicalFacet(type(IERC8109Introspection).interfaceId),
                postDeployHookFacet: facetReg.canonicalFacet(type(IPostDeployAccountHook).interfaceId),
                hookFlagsFacet: hookFlagsFacet
            })
        );
        vm.prank(owner);
        IVaultRegistryDeployment(address(indexedexManager)).setHookDiamondPackageFactory(address(hookFactory));
    }

    function _deployHookFactoryAndPkg() internal {
        _deployHookFactory();

        IFacet seFacet = CpHookFactory.deploySeFacet(create3Factory);
        IFacet depositFacet = CpHookFactory.deployDepositFacet(create3Factory);
        IFacet withdrawFacet = CpHookFactory.deployWithdrawFacet(create3Factory);
        hookPkg = CpHookFactory.deployPackage(
            IVaultRegistryDeployment(address(indexedexManager)),
            owner,
            IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage.PkgInit({
                vaultRegistryDeployment: IVaultRegistryDeployment(address(indexedexManager)),
                vaultFeeOracleQuery: IVaultFeeOracleQuery(address(indexedexManager)),
                seFacet: seFacet,
                depositFacet: depositFacet,
                depositSingleFacet: CpHookFactory.deployDepositSingleFacet(create3Factory),
                depositPreviewFacet: CpHookFactory.deployDepositPreviewFacet(create3Factory),
                withdrawFacet: withdrawFacet,
                erc20Facet: erc20Facet,
                erc5267Facet: erc5267Facet,
                erc2612Facet: erc2612Facet,
                multiAssetBasicVaultFacet: multiAssetBasicVaultFacet,
                multiAssetStandardVaultFacet: multiAssetStandardVaultFacet,
                multiStepOwnableFacet: multiStepOwnableFacet
            }),
            abi.encode(type(IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage).name, "v1")._hash()
        );
    }

    function _deployBondNftVaultPkg() internal {
        detfNFTVaultFacet = create3Factory.deployUniswapV4DetfBondNFTVaultFacet();
        erc721FacetDetf = IFacet(
            create3Factory.deployFacet(type(ERC721Facet).creationCode, keccak256("Uv4Detf_ERC721Facet"))
        );
        IUniswapV4DetfBondNFTVaultDFPkg.PkgInit memory nftPkgInit = DetfComponentFactoryService
            .buildUniswapV4DetfBondNFTVaultPkgInit(
            erc721FacetDetf,
            erc4626BasicVaultFacet,
            erc4626StandardVaultFacet,
            detfNFTVaultFacet,
            IVaultFeeOracleQuery(address(indexedexManager)),
            IVaultRegistryDeployment(address(indexedexManager))
        );
        vm.startPrank(owner);
        bondNftVaultPkg = IVaultRegistryDeployment(address(indexedexManager))
            .deployUniswapV4DetfBondNFTVaultDFPkg(nftPkgInit);
        vm.stopPrank();
        vm.label(address(bondNftVaultPkg), "Uv4Detf_BondNftVaultPkg");
    }

    function _deployRebasingClaimTokenPkg() internal {
        IFacet claimFacet_ = create3Factory.deployRebasingClaimTokenFacet();
        rebasingClaimTokenPkg = create3Factory.deployRebasingClaimTokenDFPkg(
            DetfComponentFactoryService.buildRICHIRPkgInit(
                erc20Facet, erc5267Facet, erc2612Facet, claimFacet_, diamondPackageFactory
            )
        );
        vm.label(address(rebasingClaimTokenPkg), "Uv4Detf_RebasingClaimTokenPkg");
    }

    function _deployDetfPkg() internal {
        detfProductFacets = UniswapV4Detf_Facet_FactoryService.deployUniswapV4DetfFacets(create3Factory);
        IUniswapV4DetfDFPkg.PkgInit memory pkgInit = IUniswapV4DetfDFPkg.PkgInit({
            erc20Facet: erc20Facet,
            erc5267Facet: erc5267Facet,
            erc2612Facet: erc2612Facet,
            multiAssetBasicVaultFacet: multiAssetBasicVaultFacet,
            multiAssetStandardVaultFacet: multiAssetStandardVaultFacet,
            productFacets: detfProductFacets,
            feeOracle: IVaultFeeOracleQuery(address(indexedexManager)),
            vaultRegistryDeployment: IVaultRegistryDeployment(address(indexedexManager)),
            bondNftVaultPkg: bondNftVaultPkg,
            rebasingClaimTokenPkg: rebasingClaimTokenPkg
        });
        vm.startPrank(owner);
        detfPkg = UniswapV4Detf_Pkg_FactoryService.deployUniswapV4DetfDFPkg(
            IVaultRegistryDeployment(address(indexedexManager)), pkgInit
        );
        vm.stopPrank();
        vm.label(address(detfPkg), "UniswapV4DetfDFPkg");
    }

    function _nLegDetfArgs(uint256 pairCount_) internal view returns (IUniswapV4Detf.PkgArgs memory args) {
        args = _defaultDetfArgs();
        uint256[] memory creation_ = new uint256[](pairCount_);
        for (uint256 i; i < pairCount_; ++i) {
            creation_[i] = DEFAULT_CREATION_PAIR_PER_DETF;
        }
        args.creationPairPerDetfWad = creation_;
        args.openingPairPerDetfWad = new uint256[](0);
    }

    function _defaultDetfArgs() internal view returns (IUniswapV4Detf.PkgArgs memory args) {
        uint256[] memory creation_ = new uint256[](1);
        creation_[0] = DEFAULT_CREATION_PAIR_PER_DETF;
        args = IUniswapV4Detf.PkgArgs({
            name: "UniV4 DETF",
            symbol: "uv4DETF",
            hook: address(0),
            creationPairPerDetfWad: creation_,
            openingPairPerDetfWad: new uint256[](0),
            mintThreshold: 0,
            burnThreshold: 0,
            // Open: first-bond free legs typically leave synthetic < Policy mintThreshold.
            thresholdMode: ThresholdMode.Open,
            expansionEpochLength: 0,
            expansionClosureRatePerYearWad: 0,
            expansionMaxCatchUpEpochs: 0,
            creator: address(0),
            claimName: "",
            claimSymbol: "",
            bondName: "",
            bondSymbol: "",
            mintRouteMode: IUniswapV4Detf.RouteTableMode.Default,
            mintRoutes: new IUniswapV4Detf.IoRoute[](0),
            burnRouteMode: IUniswapV4Detf.RouteTableMode.Default,
            burnRoutes: new IUniswapV4Detf.IoRoute[](0),
            bondRouteMode: IUniswapV4Detf.RouteTableMode.Default,
            bondRoutes: new IUniswapV4Detf.IoRoute[](0),
            closeRouteMode: IUniswapV4Detf.RouteTableMode.Default,
            closeRoutes: new IUniswapV4Detf.IoRoute[](0),
            donateRouteMode: IUniswapV4Detf.RouteTableMode.Default,
            donateRoutes: new IUniswapV4Detf.IoRoute[](0)
        });
    }

    function _predictDetf(IUniswapV4Detf.PkgArgs memory args) internal view returns (address) {
        IUniswapV4Detf.PkgArgs memory saltArgs_ = args;
        saltArgs_.hook = address(0);
        return diamondPackageFactory.calcAddress(
            IDiamondFactoryPackage(address(detfPkg)), abi.encode(saltArgs_)
        );
    }

    function _deployHookThenDetf(IUniswapV4Detf.PkgArgs memory args) internal virtual returns (address detf_) {
        address predicted_ = _predictDetf(args);
        IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage.PkgArgs memory hArgs =
            IUniswapV4SingleStandardExchangeBufferConstantProductHookPackage.PkgArgs({
                poolManager: address(pm),
                feeOracle: address(indexedexManager),
                standardExchange: se,
                pairToken: address(pairToken),
                rawToken: predicted_,
                pairTokenDecimals: HookPkgArgsDecimalsLib.tokenDec(address(pairToken)),
                rawTokenDecimals: predicted_.code.length == 0 ? uint8(18) : HookPkgArgsDecimalsLib.tokenDec(predicted_),
                ownerOnlyLiquidity: true,
                owner: predicted_
            });
        uint256 mineNonce = CpHookFactory.findMineNonce(hookFactory, hookPkg, hArgs);
        reserveHook = CpHookFactory.deployHook(hookPkg, hArgs, mineNonce);
        IUniswapV4HookStagedPairInit init = IUniswapV4HookStagedPairInit(reserveHook);
        init.deployPair(predicted_, address(pairToken));
        require(init.finalizeInitialization(), "finalize");
        args.hook = reserveHook;
        vm.startPrank(owner);
        detf_ = detfPkg.deployVault(args);
        vm.stopPrank();
        require(detf_ == predicted_, "detf != predicted");
        vm.label(detf_, args.symbol);
        vm.label(reserveHook, "reserveHook");
    }

    function _finalizeHookPairs() internal {
        IUniswapV4HookStagedPairInit init = IUniswapV4HookStagedPairInit(reserveHook);
        init.deployPair(detf, address(pairToken));
        bool ok = init.finalizeInitialization();
        require(ok, "finalize");
    }

    function _setDefaultBondTerms(uint256 minLock_, uint256 maxLock_) internal {
        vm.startPrank(owner);
        try IVaultFeeOracleManager(address(indexedexManager)).setDefaultBondTerms(
            BondTerms({
                minLockDuration: minLock_,
                maxLockDuration: maxLock_,
                minBonusPercentage: 0,
                maxBonusPercentage: 0.5e18
            })
        ) {} catch {}
        vm.stopPrank();
    }

    function _setBondTerms(uint256 minLock_, uint256 maxLock_) internal {
        vm.startPrank(owner);
        try IVaultFeeOracleManager(address(indexedexManager)).setVaultBondTerms(
            detf,
            BondTerms({
                minLockDuration: minLock_,
                maxLockDuration: maxLock_,
                minBonusPercentage: 0,
                maxBonusPercentage: 0.5e18
            })
        ) {} catch {}
        vm.stopPrank();
    }

    function _firstBond(uint256 pairAmount_) internal virtual returns (uint256 tokenId, uint256 shares) {
        vm.startPrank(detfUser);
        (tokenId, shares) = detfInfo.bond(
            IERC20(address(pairToken)),
            pairAmount_,
            DEFAULT_MIN_LOCK,
            detfUser,
            false,
            block.timestamp + 1 hours
        );
        vm.stopPrank();
    }

    function _deployDualHook() internal returns (address dualHook_) {
        MintableERC20Decimals tokenA = new MintableERC20Decimals("TokenA", "TKA", 18);
        MintableERC20Decimals tokenB = new MintableERC20Decimals("TokenB", "TKB", 18);
        SimpleYieldERC4626 vaultA = new SimpleYieldERC4626(tokenA);
        SimpleYieldERC4626 vaultB = new SimpleYieldERC4626(tokenB);
        address seA = _deployERC4626SE(address(vaultA));
        address seB = _deployERC4626SE(address(vaultB));
        IFacet hooksFacet = DualFactory.deployHooksFacet(create3Factory);
        IFacet depositFacet = DualFactory.deployDepositFacet(create3Factory);
        IFacet withdrawFacet = DualFactory.deployWithdrawFacet(create3Factory);
        IFacet seFacet = DualFactory.deploySeFacet(create3Factory);
        IUniswapV4DualStandardExchangeBufferConstantProductHookPackage dualPkg = DualFactory.deployPackage(
            IVaultRegistryDeployment(address(indexedexManager)),
            owner,
            IUniswapV4DualStandardExchangeBufferConstantProductHookPackage.PkgInit({
                vaultRegistryDeployment: IVaultRegistryDeployment(address(indexedexManager)),
                vaultFeeOracleQuery: IVaultFeeOracleQuery(address(indexedexManager)),
                hooksFacet: hooksFacet,
                depositFacet: depositFacet,
                withdrawFacet: withdrawFacet,
                seFacet: seFacet,
                erc20Facet: erc20Facet,
                erc5267Facet: erc5267Facet,
                erc2612Facet: erc2612Facet,
                multiAssetBasicVaultFacet: multiAssetBasicVaultFacet,
                multiAssetStandardVaultFacet: multiAssetStandardVaultFacet
            }),
            abi.encode(type(IUniswapV4DualStandardExchangeBufferConstantProductHookPackage).name, "v1")._hash()
        );
        IUniswapV4DualStandardExchangeBufferConstantProductHookPackage.PkgArgs memory args =
        IUniswapV4DualStandardExchangeBufferConstantProductHookPackage.PkgArgs({
            poolManager: address(pm),
            feeOracle: address(indexedexManager),
            standardExchange0: seA,
            token0: address(tokenA),
            standardExchange1: seB,
            token1: address(tokenB)
        });
        uint256 mineNonce = DualFactory.findMineNonce(hookFactory, dualPkg, args);
        dualHook_ = DualFactory.deployHook(dualPkg, args, mineNonce);
    }

    function _assertNoJoinableDust() internal view virtual {
        address hook_ = detfInfo.hook();
        assertEq(IERC20(hook_).balanceOf(detf), 0, "no hook LP on diamond");
        assertLe(IERC20(address(pairToken)).balanceOf(detf), 10, "no pair on diamond");
        assertLe(IERC20(se).balanceOf(detf), 10, "no SE share on diamond");
    }
}
