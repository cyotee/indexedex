// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

/* -------------------------------------------------------------------------- */
/*                                    Crane                                   */
/* -------------------------------------------------------------------------- */

import {IERC20Events} from "@crane/contracts/interfaces/IERC20Events.sol";
import {ONE_WAD} from "@crane/contracts/constants/Constants.sol";
import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {Math} from "@crane/contracts/utils/Math.sol";
import {ERC20Repo} from "@crane/contracts/tokens/ERC20/ERC20Repo.sol";
import {BetterSafeERC20} from "@crane/contracts/tokens/ERC20/utils/BetterSafeERC20.sol";
import {ReentrancyLockModifiers} from "@crane/contracts/access/reentrancy/ReentrancyLockModifiers.sol";
import {MultiStepOwnableModifiers} from "@crane/contracts/access/ERC8023/MultiStepOwnableModifiers.sol";

/* -------------------------------------------------------------------------- */
/*                                  Indexedex                                 */
/* -------------------------------------------------------------------------- */

import {IRebasingClaimToken} from "contracts/interfaces/IRebasingClaimToken.sol";
import {ISecurePullErrors} from "contracts/interfaces/ISecurePullErrors.sol";
import {IDetf} from "contracts/interfaces/detf/IDetf.sol";
import {IDETFNFTVault} from "contracts/interfaces/IDETFNFTVault.sol";
import {IDetfErrors} from "contracts/interfaces/IDetfErrors.sol";
import {RebasingClaimTokenRepo} from "contracts/vaults/detf/common/claimToken/RebasingClaimTokenRepo.sol";
import {IStandardExchangeIn} from "@crane/contracts/interfaces/IStandardExchangeIn.sol";
import {IStandardExchangeOut} from "@crane/contracts/interfaces/IStandardExchangeOut.sol";

/**
 * @title RebasingClaimTokenTarget
 * @author cyotee doge <not_cyotee@proton.me>
 * @notice Implementation of rebasing claim token rebasing token.
 * @dev rebasing claim token is a rebasing ERC20 token that:
 *      - Is minted when the protocol-owned NFT is sold
 *      - Has balanceOf() that changes over time based on redemption rate
 *      - Can be redeemed for WETH when synthetic price is below burn threshold
 *
 *      Storage model:
 *      - sharesOf[user]: Only changes on mint/burn/transfer
 *      - totalShares: Only changes on mint/burn
 *      - balanceOf(user): Computed live as sharesOf * redemptionRate / 1e18
 *      - totalSupply(): Computed live as totalShares * redemptionRate / 1e18
 */
contract RebasingClaimTokenTarget is IDetfErrors, ReentrancyLockModifiers, MultiStepOwnableModifiers, IRebasingClaimToken {
    using BetterSafeERC20 for IERC20;
    using RebasingClaimTokenRepo for RebasingClaimTokenRepo.Storage;

    /* ---------------------------------------------------------------------- */
    /*                              Events                                    */
    /* ---------------------------------------------------------------------- */

    // Note: Transfer, Approval, and RedemptionRateUpdated events are inherited from interfaces

    struct RedemptionQuote {
        uint256 rate;
        uint256 backing;
        uint256 originalShares;
        uint256 reserveLp;
        uint256 totalInternalShares;
    }


    /* ---------------------------------------------------------------------- */
    /*                          Rebasing ERC20 Core                           */
    /* ---------------------------------------------------------------------- */

    /**
     * @notice Returns the name of the token.
     */
    function name() external view returns (string memory) {
        return ERC20Repo._name();
    }

    /**
     * @notice Returns the symbol of the token.
     */
    function symbol() external view returns (string memory) {
        return ERC20Repo._symbol();
    }

    /**
     * @notice Returns the number of decimals.
     */
    function decimals() external pure returns (uint8) {
        return 18;
    }

    /**
     * @notice Total supply is the zapout of protocol-owned reserve LP (bond NFT id 0).
     * @dev Zero when there are no claim shares or the protocol NFT holds no LP.
     */
    function totalSupply() external view returns (uint256) {
        return _protocolNftZapOut(RebasingClaimTokenRepo._layoutStruct());
    }

    /**
     * @notice Returns the balance of an account (computed from shares * redemptionRate).
     * @dev This value changes over time as the redemption rate changes.
     */
    function balanceOf(address account) external view returns (uint256) {
        return _balanceOf(account);
    }

    function _balanceOf(address account) internal view returns (uint256) {
        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        uint256 rate = _getCurrentRedemptionRate(layoutStruct);
        return RebasingClaimTokenRepo._sharesToBalance(layoutStruct.sharesOf[account], rate);
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function sharesOf(address account) external view returns (uint256) {
        return RebasingClaimTokenRepo._internalSharesToExternal(RebasingClaimTokenRepo._sharesOf(account));
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function totalShares() external view returns (uint256) {
        return RebasingClaimTokenRepo._internalSharesToExternal(RebasingClaimTokenRepo._totalShares());
    }

    function hasOutstandingShares() external view returns (bool) {
        return RebasingClaimTokenRepo._totalShares() != 0;
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function redemptionRate() external view returns (uint256) {
        return _getCurrentRedemptionRate(RebasingClaimTokenRepo._layoutStruct());
    }

    /// @notice Same-tx `previewRedeem` DETF out for the in-flight `claimLiquidity` (R-22).
    function pendingRedeemDetfOut() external view returns (uint256) {
        return RebasingClaimTokenRepo._layoutStruct().pendingRedeemDetfOut;
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function detf() external view returns (address) {
        return address(RebasingClaimTokenRepo._layoutStruct().detf);
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function setDetf(address detf_) external onlyOwner {
        RebasingClaimTokenRepo._setDetf(IDetf(detf_));
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function detfNFTId() external view returns (uint256) {
        return RebasingClaimTokenRepo._layoutStruct().detfNFTId;
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function rateAsset() external view returns (IERC20) {
        return RebasingClaimTokenRepo._layoutStruct().rateAsset;
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function convertToShares(uint256 rebasingClaimAmount) external view returns (uint256 shares) {
        uint256 rate = _getCurrentRedemptionRate(RebasingClaimTokenRepo._layoutStruct());
        return RebasingClaimTokenRepo._internalSharesToExternal(RebasingClaimTokenRepo._balanceToShares(rebasingClaimAmount, rate));
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function convertToClaim(uint256 shares) external view returns (uint256 rebasingClaimAmount) {
        uint256 rate = _getCurrentRedemptionRate(RebasingClaimTokenRepo._layoutStruct());
        uint256 internalShares = RebasingClaimTokenRepo._externalSharesToInternal(shares);
        return RebasingClaimTokenRepo._sharesToBalance(internalShares, rate);
    }

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function previewRedeem(uint256 rebasingClaimAmount) external view returns (uint256 wethOut) {
        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        RedemptionQuote memory quote = _redemptionQuote(layoutStruct);
        uint256 shares = RebasingClaimTokenRepo._balanceToShares(rebasingClaimAmount, quote.rate);
        wethOut = _redemptionPayout(quote, shares);
    }

    function previewExchangeIn(IERC20 tokenIn, uint256 amountIn, IERC20 tokenOut)
        external
        view
        returns (uint256 amountOut)
    {
        if (amountIn == 0) {
            return 0;
        }
        if (address(tokenIn) != address(this)) {
            revert InvalidToken(tokenIn);
        }
        if (address(tokenOut) != address(RebasingClaimTokenRepo._layoutStruct().rateAsset)) {
            revert InvalidToken(tokenOut);
        }

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        RedemptionQuote memory quote = _redemptionQuote(layoutStruct);
        uint256 shares = RebasingClaimTokenRepo._balanceToShares(amountIn, quote.rate);
        amountOut = _redemptionPayout(quote, shares);
    }

    function previewExchangeOut(IERC20 tokenIn, IERC20 tokenOut, uint256 amountOut)
        external
        view
        returns (uint256 amountIn)
    {
        if (amountOut == 0) {
            return 0;
        }
        if (address(tokenIn) != address(this)) {
            revert InvalidToken(tokenIn);
        }
        if (address(tokenOut) != address(RebasingClaimTokenRepo._layoutStruct().rateAsset)) {
            revert InvalidToken(tokenOut);
        }

        RedemptionQuote memory quote = _redemptionQuote(RebasingClaimTokenRepo._layoutStruct());
        amountIn = _claimAmountForExactOutput(amountOut, quote);
    }

    /// @dev Invert the internal-share, NFT-share and reserve-LP floors. Each step
    ///      rounds input up so even a coarse LP denomination funds the requested output.
    function _claimAmountForExactOutput(uint256 amountOut_, RedemptionQuote memory q) internal pure returns (uint256) {
        if (q.rate == 0 || q.backing == 0 || amountOut_ > q.backing) revert IStandardExchangeOut.ExchangeOutNotAvailable();
        uint256 lp = Math.mulDiv(amountOut_, q.reserveLp, q.backing, Math.Rounding.Ceil);
        uint256 original = Math.mulDiv(lp, q.originalShares, q.reserveLp, Math.Rounding.Ceil);
        uint256 shares = Math.mulDiv(original, q.totalInternalShares, q.originalShares, Math.Rounding.Ceil);
        uint256 balanceShares = Math.mulDiv(amountOut_, RebasingClaimTokenRepo._shareUnit(), q.rate, Math.Rounding.Ceil);
        if (balanceShares > shares) shares = balanceShares;
        return Math.mulDiv(shares, q.rate, RebasingClaimTokenRepo._shareUnit(), Math.Rounding.Ceil);
    }

    function _redemptionQuote(RebasingClaimTokenRepo.Storage storage s) internal view returns (RedemptionQuote memory q) {
        q.totalInternalShares = s.totalShares;
        if (q.totalInternalShares == 0) { q.rate = ONE_WAD; return q; }
        q.originalShares = s.nftVault.originalSharesOf(s.detfNFTId);
        if (q.originalShares == 0) {
            q.originalShares = s.nftVault.getPosition(s.detfNFTId).originalShares;
        }
        if (q.originalShares == 0) return q;
        q.reserveLp = q.originalShares;
        try s.nftVault.convertToAssets(q.originalShares) returns (uint256 assets) { q.reserveLp = assets; } catch {}
        if (q.reserveLp == 0) return q;
        q.backing = _reserveShareZapOut(s, q.reserveLp);
        q.rate = Math.mulDiv(q.backing, RebasingClaimTokenRepo._shareUnit(), q.totalInternalShares);
    }

    /// @dev Quote only the backing represented by the whole reserve LP that will be unwound.
    function _redemptionPayout(RedemptionQuote memory q, uint256 shares) internal pure returns (uint256 payout) {
        if (shares == 0 || q.originalShares == 0 || q.reserveLp == 0) return 0;
        uint256 original = Math.mulDiv(shares, q.originalShares, q.totalInternalShares);
        uint256 lp = Math.mulDiv(original, q.reserveLp, q.originalShares);
        payout = Math.mulDiv(lp, q.backing, q.reserveLp);
        uint256 balanceValue = RebasingClaimTokenRepo._sharesToBalance(shares, q.rate);
        if (payout > balanceValue) payout = balanceValue;
    }

    /* ---------------------------------------------------------------------- */
    /*                          ERC20 Transfers                               */
    /* ---------------------------------------------------------------------- */

    /**
     * @notice Transfers tokens to a recipient.
     * @dev Converts balance amount to shares for internal accounting.
     */
    function transfer(address to, uint256 amount) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    /**
     * @notice Returns the allowance.
     */
    function allowance(address owner, address spender) external view returns (uint256) {
        return ERC20Repo._allowance(owner, spender);
    }

    /**
     * @notice Approves a spender.
     */
    function approve(address spender, uint256 amount) external returns (bool) {
        ERC20Repo._approve(msg.sender, spender, amount);
        emit IERC20Events.Approval(msg.sender, spender, amount);
        return true;
    }

    /**
     * @notice Transfers tokens from one address to another.
     */
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        ERC20Repo._spendAllowance(ERC20Repo._layoutStruct(), from, msg.sender, amount);
        _transfer(from, to, amount);
        return true;
    }

    /**
     * @dev Internal transfer function.
     */
    function _transfer(address from, address to, uint256 amount) internal {
        if (from == address(0)) revert ZeroAmount();
        if (to == address(0)) revert ZeroAmount();
        if (amount == 0) {
            emit IERC20Events.Transfer(from, to, 0);
            return;
        }

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        uint256 rate = _getCurrentRedemptionRate(layoutStruct);
        _transferAtRate(layoutStruct, from, to, amount, rate);
    }

    function _transferAtRate(
        RebasingClaimTokenRepo.Storage storage layoutStruct, address from, address to, uint256 amount, uint256 rate
    ) internal {
        uint256 shares = RebasingClaimTokenRepo._balanceToShares(amount, rate);
        if (shares == 0) revert ZeroAmount();

        // Check sender has enough shares
        if (layoutStruct.sharesOf[from] < shares) {
            revert InsufficientBalance(
                RebasingClaimTokenRepo._internalSharesToExternal(shares),
                RebasingClaimTokenRepo._internalSharesToExternal(layoutStruct.sharesOf[from])
            );
        }
        uint256 availableBalance = RebasingClaimTokenRepo._sharesToBalance(layoutStruct.sharesOf[from], rate);
        if (amount > availableBalance) revert InsufficientBalance(amount, availableBalance);

        // Transfer shares
        RebasingClaimTokenRepo._transferShares(layoutStruct, from, to, shares);

        emit IERC20Events.Transfer(from, to, amount);
    }

    /* ---------------------------------------------------------------------- */
    /*                          Mint (NFT Sale Only)                          */
    /* ---------------------------------------------------------------------- */

    function previewMintFromNFTSale(uint256 assets, uint256 totalAssetsBefore, uint256 backingAfter)
        external view returns (uint256)
    {
        uint256 supply = RebasingClaimTokenRepo._totalShares();
        uint256 issued = totalAssetsBefore == 0
            ? RebasingClaimTokenRepo._externalSharesToInternal(assets)
            : Math.mulDiv(assets, supply, totalAssetsBefore);
        if (issued == 0) return 0;
        uint256 rate = Math.mulDiv(backingAfter, RebasingClaimTokenRepo._shareUnit(), supply + issued);
        return RebasingClaimTokenRepo._sharesToBalance(issued, rate);
    }

    function mintFromNFTSale(uint256 lpShares, address recipient) external onlyOwner returns (uint256 rebasingClaimMinted) {
        return mintFromNFTSale(lpShares, type(uint256).max, recipient);
    }

    /// @inheritdoc IRebasingClaimToken
    function mintFromNFTSale(uint256 assets, uint256 totalAssetsBefore, address recipient)
        public
        onlyOwner
        returns (uint256 rebasingClaimMinted)
    {
        if (assets == 0) revert ZeroAmount();

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        uint256 totalAssets = totalAssetsBefore == type(uint256).max
            ? layoutStruct.nftVault.originalSharesOf(layoutStruct.detfNFTId)
            : totalAssetsBefore;
        uint256 internalShares = totalAssets == 0
            ? RebasingClaimTokenRepo._externalSharesToInternal(assets)
            : Math.mulDiv(assets, layoutStruct.totalShares, totalAssets);
        if (internalShares == 0) revert ZeroAmount();

        RebasingClaimTokenRepo._mintShares(layoutStruct, recipient, internalShares);

        uint256 rate = _getCurrentRedemptionRate(layoutStruct);
        rebasingClaimMinted = RebasingClaimTokenRepo._sharesToBalance(internalShares, rate);
        if (rebasingClaimMinted == 0) revert ZeroAmount();

        emit IRebasingClaimToken.Minted(
            recipient, assets, RebasingClaimTokenRepo._internalSharesToExternal(internalShares), rebasingClaimMinted
        );
        emit IERC20Events.Transfer(address(0), recipient, rebasingClaimMinted);
    }

    /* ---------------------------------------------------------------------- */
    /*                          Redemption                                    */
    /* ---------------------------------------------------------------------- */

    /**
     * @inheritdoc IRebasingClaimToken
     */
    function redeem(uint256 rebasingClaimAmount, address recipient, bool pretransferred)
        external
        nonReentrant
        returns (uint256 wethOut)
    {
        if (rebasingClaimAmount == 0) revert ZeroAmount();

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        RedemptionQuote memory quote = _redemptionQuote(layoutStruct);
        _secureClaimTransfer(layoutStruct, rebasingClaimAmount, pretransferred, quote.rate);
        wethOut = _executeRedeem(layoutStruct, rebasingClaimAmount, recipient == address(0) ? msg.sender : recipient, quote);
    }

    function exchangeIn(
        IERC20 tokenIn,
        uint256 amountIn,
        IERC20 tokenOut,
        uint256 minAmountOut,
        address recipient,
        bool pretransferred,
        uint256 deadline
    ) external nonReentrant returns (uint256 amountOut) {
        if (block.timestamp > deadline) {
            revert DeadlineExceeded(deadline, block.timestamp);
        }
        if (amountIn == 0) revert ZeroAmount();
        if (address(tokenIn) != address(this)) {
            revert InvalidToken(tokenIn);
        }

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        if (address(tokenOut) != address(layoutStruct.rateAsset)) {
            revert InvalidToken(tokenOut);
        }

        RedemptionQuote memory quote = _redemptionQuote(layoutStruct);
        _secureClaimTransfer(layoutStruct, amountIn, pretransferred, quote.rate);
        amountOut = _executeRedeem(layoutStruct, amountIn, recipient == address(0) ? msg.sender : recipient, quote);
        if (amountOut < minAmountOut) {
            revert SlippageExceeded(minAmountOut, amountOut);
        }
    }

    function exchangeOut(
        IERC20 tokenIn,
        uint256 maxAmountIn,
        IERC20 tokenOut,
        uint256 amountOut,
        address recipient,
        bool pretransferred,
        uint256 deadline
    ) external nonReentrant returns (uint256 amountIn) {
        if (block.timestamp > deadline) {
            revert DeadlineExceeded(deadline, block.timestamp);
        }
        if (amountOut == 0) revert ZeroAmount();
        if (address(tokenIn) != address(this)) {
            revert InvalidToken(tokenIn);
        }

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        if (address(tokenOut) != address(layoutStruct.rateAsset)) {
            revert InvalidToken(tokenOut);
        }

        RedemptionQuote memory quote = _redemptionQuote(layoutStruct);
        amountIn = _claimAmountForExactOutput(amountOut, quote);
        if (amountIn > maxAmountIn) {
            revert SlippageExceeded(maxAmountIn, amountIn);
        }

        _secureClaimTransfer(layoutStruct, amountIn, pretransferred, quote.rate);
        uint256 actualOut = _executeRedeem(layoutStruct, amountIn, recipient == address(0) ? msg.sender : recipient, quote);
        if (actualOut < amountOut) {
            revert SlippageExceeded(amountOut, actualOut);
        }

    }

    /**
     * @inheritdoc IRebasingClaimToken
     * @dev Owner (DETF) pulls foreign ERC-20 held here (protocol reserve LP custody).
     *      Not nonReentrant: DETF claimLiquidity may call this while claim redeem holds the lock (L-CLAIM-1 unwind).
     */
    function transferHeldToken(IERC20 token, address to, uint256 amount) external onlyOwner {
        if (to == address(0) || address(token) == address(0)) revert ZeroAmount();
        if (amount == 0) revert ZeroAmount();
        token.safeTransfer(to, amount);
    }

    /**
     * @inheritdoc IRebasingClaimToken
     * @dev Only callable by the DETF diamond owner.
     */
    function burnShares(uint256 rebasingClaimAmount, address owner, bool pretransferred)
        external
        onlyOwner
        nonReentrant
        returns (uint256 sharesBurned)
    {
        if (rebasingClaimAmount == 0) revert ZeroAmount();

        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        uint256 rate = _getCurrentRedemptionRate(layoutStruct);
        uint256 internalSharesBurned = RebasingClaimTokenRepo._balanceToShares(rebasingClaimAmount, rate);

        // L-GAPS-9/10 / L-CLAIM-3: pretransferred burns only shares already held on this diamond.
        // Owner-only path; redeem/exchange use _secureTokenTransfer delta gate for free-credit.
        address burnFrom = owner;
        if (pretransferred) {
            burnFrom = address(this);
        }

        // Check owner has enough shares
        if (layoutStruct.sharesOf[burnFrom] < internalSharesBurned) {
            revert InsufficientBalance(
                RebasingClaimTokenRepo._internalSharesToExternal(internalSharesBurned),
                RebasingClaimTokenRepo._internalSharesToExternal(layoutStruct.sharesOf[burnFrom])
            );
        }

        // Burn shares (no rateAsset transfer - caller/DETF handles LP unwind)
        RebasingClaimTokenRepo._burnShares(layoutStruct, burnFrom, internalSharesBurned);

        sharesBurned = RebasingClaimTokenRepo._internalSharesToExternal(internalSharesBurned);

        emit IERC20Events.Transfer(burnFrom, address(0), rebasingClaimAmount);
    }

    /* ---------------------------------------------------------------------- */
    /*                       Redemption Rate Updates                          */
    /* ---------------------------------------------------------------------- */

    /**
     * @notice Updates the cached redemption rate.
     * @dev Can be called by anyone to refresh the rate.
     */
    function updateRedemptionRate() external {
        RebasingClaimTokenRepo.Storage storage layoutStruct = RebasingClaimTokenRepo._layoutStruct();
        uint256 oldRate = layoutStruct.cachedRedemptionRate;
        uint256 newRate = _calcCurrentRedemptionRate(layoutStruct);

        if (newRate != oldRate) {
            RebasingClaimTokenRepo._setCachedRedemptionRate(layoutStruct, newRate);
            emit IRebasingClaimToken.RedemptionRateUpdated(oldRate, newRate);
        }
    }

    /* ---------------------------------------------------------------------- */
    /*                       Internal Rate Calculation                        */
    /* ---------------------------------------------------------------------- */

    // --- no temporary debug errors here; production path calls into the
    // DETF diamond `previewExchangeIn` to value the protocol-owned BPT.

    /**
     * @dev Converts internal claim shares without discarding fractional ownership.
     *      ERC-4626 assets are originalSharesOf(detfNFTId), never diamond BPT balance.
     */
    function _convertInternalSharesToProtocolBpt(
        RebasingClaimTokenRepo.Storage storage layoutStruct_,
        uint256 internalShares_
    ) internal view returns (uint256 bptOut_) {
        uint256 totalShares_ = layoutStruct_.totalShares;
        if (totalShares_ == 0 || internalShares_ == 0) {
            return 0;
        }
        uint256 totalAssets_ = layoutStruct_.nftVault.originalSharesOf(layoutStruct_.detfNFTId);
        bptOut_ = Math.mulDiv(internalShares_, totalAssets_, totalShares_);
    }

    /// @dev Reserve backing can change multiple times within one block. The
    ///      explicit rate-update snapshot is not a cache for live token accounting.
    function _getCurrentRedemptionRate(RebasingClaimTokenRepo.Storage storage layoutStruct_) internal view returns (uint256) {
        return _calcCurrentRedemptionRate(layoutStruct_);
    }

    function _executeRedeem(RebasingClaimTokenRepo.Storage storage layoutStruct_, uint256 rebasingClaimAmount_, address recipient_, RedemptionQuote memory quote)
        internal
        returns (uint256 wethOut_)
    {
        uint256 shares = RebasingClaimTokenRepo._balanceToShares(rebasingClaimAmount_, quote.rate);

        if (layoutStruct_.sharesOf[address(this)] < shares) {
            revert InsufficientBalance(
                RebasingClaimTokenRepo._internalSharesToExternal(shares),
                RebasingClaimTokenRepo._internalSharesToExternal(layoutStruct_.sharesOf[address(this)])
            );
        }

        // 4626 convertToAssets against protocol NFT originalShares (before burn).
        uint256 bptOut_ = _convertInternalSharesToProtocolBpt(layoutStruct_, shares);
        if (bptOut_ == 0) revert ZeroAmount();

        // R-22: same two-step as previewRedeem, consumed by DETF claimLiquidity in this tx.
        layoutStruct_.pendingRedeemDetfOut = _redemptionPayout(quote, shares);
        if (layoutStruct_.pendingRedeemDetfOut == 0) revert ZeroAmount();

        // Burn claim shares first (CEI).
        RebasingClaimTokenRepo._burnShares(layoutStruct_, address(this), shares);

        // L-CLAIM-1/2: fund redeem by unwinding protocol NFT LP via DETF - not idle rateAsset inventory.
        wethOut_ = layoutStruct_.detf.claimLiquidity(bptOut_, recipient_);
        layoutStruct_.pendingRedeemDetfOut = 0;

        emit IRebasingClaimToken.Redeemed(
            msg.sender, recipient_, rebasingClaimAmount_, bptOut_, wethOut_
        );
        emit IERC20Events.Transfer(address(this), address(0), rebasingClaimAmount_);
    }

    /// @dev Transfer the caller's internal shares using the operation's single pre-transfer rate.
    ///      A pretransfer cannot provide an in-call self-token delta; existing idle shares never fund it.
    function _secureClaimTransfer(
        RebasingClaimTokenRepo.Storage storage layoutStruct, uint256 amount, bool pretransferred, uint256 rate
    ) internal {
        if (pretransferred) revert ISecurePullErrors.TransferDeltaInsufficient(amount, 0);
        _transferAtRate(layoutStruct, msg.sender, address(this), amount, rate);
    }

    /**
     * @dev Rate such that balanceOf = pro-rata of `_protocolNftZapOut` (totalSupply).
     */
    function _calcCurrentRedemptionRate(RebasingClaimTokenRepo.Storage storage layoutStruct_) internal view returns (uint256 rate) {
        uint256 totalShares_ = layoutStruct_.totalShares;
        if (totalShares_ == 0) {
            return ONE_WAD;
        }

        uint256 zapout_ = _protocolNftZapOut(layoutStruct_);
        // D10: outstanding shares are worth their extractable backing, including zero.
        rate = Math.mulDiv(zapout_, RebasingClaimTokenRepo._shareUnit(), totalShares_);
    }

    /// @dev Zapout of the protocol bond NFT's whole reserve-LP slice (4626 assets, then single-sided exit).
    function _protocolNftZapOut(RebasingClaimTokenRepo.Storage storage layoutStruct_)
        internal
        view
        returns (uint256 zapout_)
    {
        if (layoutStruct_.totalShares == 0) return 0;
        uint256 orig_ = layoutStruct_.nftVault.originalSharesOf(layoutStruct_.detfNFTId);
        if (orig_ == 0) {
            IDETFNFTVault.Position memory position_ = layoutStruct_.nftVault.getPosition(layoutStruct_.detfNFTId);
            orig_ = position_.originalShares;
        }
        if (orig_ == 0) return 0;

        uint256 lp_ = orig_;
        try layoutStruct_.nftVault.convertToAssets(orig_) returns (uint256 assets_) {
            lp_ = assets_;
        } catch {}

        if (lp_ == 0) return 0;
        return _reserveShareZapOut(layoutStruct_, lp_);
    }

    /// @dev Canonical quote: DETF `previewClaimLiquidity` (reserve LP zapout). Fallback: previewExchangeIn.
    function _reserveShareZapOut(RebasingClaimTokenRepo.Storage storage layoutStruct_, uint256 lpAmount_)
        internal
        view
        returns (uint256 zapout_)
    {
        try layoutStruct_.detf.previewClaimLiquidity(lpAmount_) returns (uint256 z_) {
            return z_;
        } catch {
            IERC20 bpt = IERC20(layoutStruct_.detf.reservePool());
            return IStandardExchangeIn(address(layoutStruct_.detf)).previewExchangeIn(
                bpt, lpAmount_, layoutStruct_.rateAsset
            );
        }
    }
}
