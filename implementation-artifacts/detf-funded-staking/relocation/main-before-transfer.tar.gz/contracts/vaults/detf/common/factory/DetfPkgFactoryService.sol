// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;
import {ArtifactCreationCode} from "contracts/utils/foundry/ArtifactCreationCode.sol";

/* -------------------------------------------------------------------------- */
/*                                   Foundry                                  */
/* -------------------------------------------------------------------------- */

import {Vm} from "forge-std/Vm.sol";

/* -------------------------------------------------------------------------- */
/*                                    Crane                                   */
/* -------------------------------------------------------------------------- */

import {VM_ADDRESS} from "@crane/contracts/constants/FoundryConstants.sol";
import {ICreate3FactoryProxy} from "@crane/contracts/interfaces/proxies/ICreate3FactoryProxy.sol";
import {BetterEfficientHashLib} from "@crane/contracts/utils/BetterEfficientHashLib.sol";

/* -------------------------------------------------------------------------- */
/*                                  Indexedex                                 */
/* -------------------------------------------------------------------------- */

import {IVaultRegistryDeployment} from "contracts/interfaces/IVaultRegistryDeployment.sol";
import {IDETFNFTVaultDFPkg} from "contracts/vaults/detf/common/bondNft/DETFNFTVaultDFPkg.sol";
import {IUniswapV4DetfBondNFTVaultDFPkg} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/bondNft/UniswapV4DetfBondNFTVaultDFPkg.sol";

import {IUniswapV4DetfDFPkg} from "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/interfaces/IUniswapV4Detf.sol";
import {IDetfSelfNftInventoryDFPkg} from "contracts/vaults/detf/common/factory/nft/IDetfSelfNftInventoryDFPkg.sol";
import {IRebasingClaimTokenDFPkg} from "contracts/vaults/detf/common/claimToken/RebasingClaimTokenDFPkg.sol";
import {IRebasingDETFTokenDFPkg} from "contracts/vaults/detf/protocols/dexes/balancer/v3/stable/common/RebasingDETFTokenDFPkg.sol";

library DetfPkgFactoryService {
    using BetterEfficientHashLib for bytes;

    Vm constant vm = Vm(VM_ADDRESS);

    function deployDETFNFTVaultDFPkg(
        IVaultRegistryDeployment vaultRegistry,
        IDETFNFTVaultDFPkg.PkgInit memory pkgInit
    ) internal returns (IDetfSelfNftInventoryDFPkg instance) {
        instance = IDetfSelfNftInventoryDFPkg(
            address(
                vaultRegistry.deployPkg(
                    ArtifactCreationCode.creationCode("DETFNFTVaultDFPkg.sol:DETFNFTVaultDFPkg"),
                    abi.encode(pkgInit),
                    abi.encode("DETFNFTVaultDFPkg")._hash()
                )
            )
        );
        vm.label(address(instance), "DETFNFTVaultDFPkg");
    }

    function deployUniswapV4DetfDFPkg(
        IVaultRegistryDeployment vaultRegistry,
        IUniswapV4DetfDFPkg.PkgInit memory pkgInit
    ) internal returns (IUniswapV4DetfDFPkg instance) {
        bytes memory initCode_ = ArtifactCreationCode.creationCode("UniswapV4DetfDFPkg.sol:UniswapV4DetfDFPkg");
        bytes memory initArgs_ = abi.encode(pkgInit);
        instance = IUniswapV4DetfDFPkg(
            address(
                vaultRegistry.deployPkg(
                    initCode_,
                    initArgs_,
                    ArtifactCreationCode.releaseSalt(abi.encode("UniswapV4DetfDFPkg")._hash(), initCode_, initArgs_)
                )
            )
        );
        vm.label(address(instance), "UniswapV4DetfDFPkg");
    }

    function deployUniswapV4DetfBondNFTVaultDFPkg(
        IVaultRegistryDeployment vaultRegistry,
        IUniswapV4DetfBondNFTVaultDFPkg.PkgInit memory pkgInit
    ) internal returns (IUniswapV4DetfBondNFTVaultDFPkg instance) {
        bytes memory initCode_ = ArtifactCreationCode.creationCode("UniswapV4DetfBondNFTVaultDFPkg.sol:UniswapV4DetfBondNFTVaultDFPkg");
        bytes memory initArgs_ = abi.encode(pkgInit);
        instance = IUniswapV4DetfBondNFTVaultDFPkg(
            address(
                vaultRegistry.deployPkg(
                    initCode_,
                    initArgs_,
                    ArtifactCreationCode.releaseSalt(abi.encode("UniswapV4DetfBondNFTVaultDFPkg")._hash(), initCode_, initArgs_)
                )
            )
        );
        vm.label(address(instance), "UniswapV4DetfBondNFTVaultDFPkg");
    }

    function deployRebasingDETFTokenDFPkg(
        ICreate3FactoryProxy create3Factory,
        IRebasingDETFTokenDFPkg.PkgInit memory pkgInit
    ) internal returns (IRebasingDETFTokenDFPkg instance) {
        instance = IRebasingDETFTokenDFPkg(
            address(
                create3Factory.deployPackageWithArgs(
                    ArtifactCreationCode.creationCode("RebasingDETFTokenDFPkg.sol:RebasingDETFTokenDFPkg"),
                    abi.encode(pkgInit),
                    abi.encode("RebasingDETFTokenDFPkg")._hash()
                )
            )
        );
        vm.label(address(instance), "RebasingDETFTokenDFPkg");
    }

    function deployRebasingClaimTokenDFPkg(ICreate3FactoryProxy create3Factory, IRebasingClaimTokenDFPkg.PkgInit memory pkgInit)
        internal
        returns (IRebasingClaimTokenDFPkg instance)
    {
        bytes memory initCode_ = ArtifactCreationCode.creationCode("RebasingClaimTokenDFPkg.sol:RebasingClaimTokenDFPkg");
        bytes memory initArgs_ = abi.encode(pkgInit);
        instance = IRebasingClaimTokenDFPkg(
            address(
                create3Factory.deployPackageWithArgs(
                    initCode_,
                    initArgs_,
                    ArtifactCreationCode.releaseSalt(abi.encode("RebasingClaimTokenDFPkg")._hash(), initCode_, initArgs_)
                )
            )
        );
        vm.label(address(instance), "RebasingClaimTokenDFPkg");
    }
}