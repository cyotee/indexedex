// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IERC20Metadata} from "@crane/contracts/interfaces/IERC20Metadata.sol";
import {BetterSafeERC20 as SafeERC20} from "@crane/contracts/tokens/ERC20/utils/BetterSafeERC20.sol";
import {ERC20Repo} from "@crane/contracts/tokens/ERC20/ERC20Repo.sol";
import {
    toBeforeSwapDelta,
    BeforeSwapDelta
} from "@crane/contracts/protocols/dexes/uniswap/v4/types/BeforeSwapDelta.sol";
import {Currency} from "@crane/contracts/protocols/dexes/uniswap/v4/types/Currency.sol";
import {PoolKey} from "@crane/contracts/protocols/dexes/uniswap/v4/types/PoolKey.sol";
import {IHooks} from "@crane/contracts/protocols/dexes/uniswap/v4/interfaces/IHooks.sol";
import {IPoolManager} from "@crane/contracts/protocols/dexes/uniswap/v4/interfaces/IPoolManager.sol";
import {Hooks} from "@crane/contracts/protocols/dexes/uniswap/v4/libraries/Hooks.sol";
import {LPFeeLibrary} from "@crane/contracts/protocols/dexes/uniswap/v4/libraries/LPFeeLibrary.sol";
import {ModifyLiquidityParams, SwapParams} from
    "@crane/contracts/protocols/dexes/uniswap/v4/types/PoolOperation.sol";
import {BalanceDelta} from "@crane/contracts/protocols/dexes/uniswap/v4/types/BalanceDelta.sol";
import {IStandardExchangeIn} from "@crane/contracts/interfaces/IStandardExchangeIn.sol";
import {IStandardExchangeOut} from "@crane/contracts/interfaces/IStandardExchangeOut.sol";
import {IRateProvider} from
    "@crane/contracts/protocols/dexes/balancer/common/interfaces/IRateProvider.sol";
import {IAllowanceTransfer} from
    "@crane/contracts/interfaces/protocols/utils/permit2/IAllowanceTransfer.sol";
import {IVaultFeeOracleQuery} from "contracts/interfaces/IVaultFeeOracleQuery.sol";
import {MultiAssetBasicVaultRepo} from "contracts/vaults/basic/MultiAssetBasicVaultRepo.sol";
import {
    IUniswapV4StandardExchangeWeightedBufferHook
} from "contracts/hooks/uniswap/v4/standardExchange/weighted/interfaces/IUniswapV4StandardExchangeWeightedBufferHook.sol";
import {
    UniswapV4StandardExchangeWeightedBufferHookRepo as Repo
} from "contracts/hooks/uniswap/v4/standardExchange/weighted/UniswapV4StandardExchangeWeightedBufferHookRepo.sol";
import {
    UniswapV4StandardExchangeWeightedBufferHookMath as Math
} from "contracts/hooks/uniswap/v4/standardExchange/weighted/UniswapV4StandardExchangeWeightedBufferHookMath.sol";
import {
    UniswapV4StandardExchangeWeightedBufferHookPairPoolLib as PairPoolLib
} from "contracts/hooks/uniswap/v4/standardExchange/weighted/UniswapV4StandardExchangeWeightedBufferHookPairPoolLib.sol";
import {IUniswapV4SeBufferHook} from "contracts/hooks/uniswap/v4/interfaces/IUniswapV4SeBufferHook.sol";
import {
    UniswapV4SeBufferHookLegLib
} from "contracts/hooks/uniswap/v4/libs/UniswapV4SeBufferHookLegLib.sol";

/**
 * @title UniswapV4StandardExchangeWeightedBufferHookTarget
 * @notice Product logic: dual-scale weighted book, SE buffer-last LP, rated V4/SE swaps, MultiAssetLiquidity.
 * @dev No BaseHook / DeltaResolver inheritance. LP via ERC20Repo; inventory = face | live SE shares.
 */
import {
    UniswapV4StandardExchangeWeightedBufferHookLiquidityLib as LiqLib
} from "contracts/hooks/uniswap/v4/standardExchange/weighted/UniswapV4StandardExchangeWeightedBufferHookLiquidityLib.sol";
import {
    UniswapV4StandardExchangeWeightedBufferHookTarget
} from "contracts/hooks/uniswap/v4/standardExchange/weighted/UniswapV4StandardExchangeWeightedBufferHookTarget.sol";

/**
 * @title UniswapV4StandardExchangeWeightedBufferHookExitTarget
 * @notice Join/exit + one-token aliases (inventory domain, buffer-last).
 */
abstract contract UniswapV4StandardExchangeWeightedBufferHookExitTarget is
    UniswapV4StandardExchangeWeightedBufferHookTarget
{
    using SafeERC20 for IERC20;

/* ---------------------------------------------------------------------- */
    /*                         liquidity: join / exit                         */
    /* ---------------------------------------------------------------------- */

    function _invToPairOutPreview(uint256[] memory invOut)
        internal
        view
        returns (uint256[] memory pairOut)
    {
        Repo.Layout storage l = Repo._layout();
        pairOut = new uint256[](l.numTokens);
        for (uint8 i; i < l.numTokens; ++i) {
            if (invOut[i] == 0) continue;
            address se = l.standardExchanges[i];
            if (se == address(0)) {
                pairOut[i] = invOut[i];
            } else {
                pairOut[i] = IStandardExchangeIn(se).previewExchangeIn(
                    IERC20(se), invOut[i], IERC20(l.tokens[i])
                );
            }
        }
    }


    function _edgeToInvPreview(uint256[] memory amounts, bool[] memory amountIsSeShare)
        internal
        view
        returns (uint256[] memory invDeltas)
    {
        Repo.Layout storage l = Repo._layout();
        invDeltas = new uint256[](l.numTokens);
        for (uint8 i; i < l.numTokens; ++i) {
            if (amounts[i] == 0) continue;
            if (amountIsSeShare[i]) {
                invDeltas[i] = amounts[i];
            } else {
                address se = l.standardExchanges[i];
                if (se == address(0)) {
                    invDeltas[i] = amounts[i];
                } else {
                    invDeltas[i] = IStandardExchangeIn(se).previewExchangeIn(
                        IERC20(l.tokens[i]), amounts[i], IERC20(se)
                    );
                }
            }
        }
    }


    function _validateSeShareFlags(bool[] memory flags) internal view {
        Repo.Layout storage l = Repo._layout();
        if (flags.length != l.numTokens) revert ArrayLengthMismatch();
        for (uint8 i; i < l.numTokens; ++i) {
            if (flags[i] && l.standardExchanges[i] == address(0)) revert SeShareNotBuffered();
        }
    }


    function _invToEdgeOutPreview(uint256[] memory invOut, bool[] memory receiveSeShare)
        internal
        view
        returns (uint256[] memory edgeOut)
    {
        Repo.Layout storage l = Repo._layout();
        edgeOut = new uint256[](l.numTokens);
        for (uint8 i; i < l.numTokens; ++i) {
            if (invOut[i] == 0) continue;
            address se = l.standardExchanges[i];
            if (se == address(0)) {
                edgeOut[i] = invOut[i];
            } else if (receiveSeShare[i]) {
                edgeOut[i] = invOut[i];
            } else {
                edgeOut[i] = IStandardExchangeIn(se).previewExchangeIn(
                    IERC20(se), invOut[i], IERC20(l.tokens[i])
                );
            }
        }
    }


    function previewBurnToToken(uint256 lpAmount, address tokenOut)
        external
        view
        returns (uint256 amountOut)
    {
        if (lpAmount == 0 || _previewSupplyAfterProtocolMint() == 0) return 0;
        Repo.Layout storage l = Repo._layout();
        UniswapV4SeBufferHookLegLib.LegKind k =
            UniswapV4SeBufferHookLegLib.classify(l.legs, tokenOut);
        if (k == UniswapV4SeBufferHookLegLib.LegKind.Unknown) return 0;
        if (k == UniswapV4SeBufferHookLegLib.LegKind.StandardExchange) {
            tokenOut = l.legs.pairOfStandardExchange[tokenOut];
        }
        uint256[] memory amounts = previewExitProportional(lpAmount);
        address detf_ = l.legs.detfToken;
        for (uint8 i; i < l.numTokens; ++i) {
            if (amounts[i] == 0) continue;
            address t = l.tokens[i];
            if (t == tokenOut) {
                amountOut += amounts[i];
            } else if (t == detf_) {
                continue;
            } else {
                try IUniswapV4SeBufferHook(address(this)).previewSwapExactIn(t, tokenOut, amounts[i])
                    returns (uint256 so)
                {
                    amountOut += so;
                } catch {}
            }
        }
    }

    function previewExitProportional(uint256 shares)
        public
        view
        returns (uint256[] memory amounts)
    {
        // amounts = pair-token edge
        uint256[] memory natives = _nativeAll();
        uint256[] memory invOut = Math.proportionalExitAmounts(shares, natives, _previewSupplyAfterProtocolMint());
        amounts = _invToPairOutPreview(invOut);
    }


    function exitProportional(
        uint256 shares,
        address to,
        uint256[] calldata amountsMin,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256[] memory amounts) {
        _requireDeadline(deadline);
        if (to == address(0)) revert ZeroAddress();
        if (shares == 0) revert ZeroAmount();
        _maybeMintProtocolFee();
        Repo.Layout storage l = Repo._layout();
        if (amountsMin.length != l.numTokens) revert InvalidN();
        uint256[] memory natives = _nativeAll();
        uint256[] memory invOut = Math.proportionalExitAmounts(shares, natives, _totalSupply());
        if (Math.isFullBookReserves(natives)) {
            for (uint256 i; i < l.numTokens; ++i) {
                if (invOut[i] >= natives[i]) revert WouldZeroReserve();
            }
        }
        amounts = _invToPairOutPreview(invOut);
        for (uint256 i; i < l.numTokens; ++i) {
            if (amounts[i] < amountsMin[i]) revert Slippage();
        }
        _burnLp(msg.sender, shares);
        for (uint8 i; i < l.numTokens; ++i) {
            if (invOut[i] == 0) continue;
            if (l.standardExchanges[i] != address(0)) {
                _unwrapSeShares(i, invOut[i], to);
            } else {
                l.rawReserves[i] -= invOut[i];
                IERC20(l.tokens[i]).safeTransfer(to, invOut[i]);
            }
        }
        _snapshotKLastIfFeeOn();
        _syncVaultReserves();
        int256[] memory deltas = new int256[](l.numTokens);
        for (uint256 i; i < l.numTokens; ++i) {
            deltas[i] = -int256(amounts[i]);
        }
        emit IUniswapV4StandardExchangeWeightedBufferHook.Exit(msg.sender, to, shares, deltas, 0);
    }


    function previewExitSingleAssetExactBptIn(address tokenOut, uint256 sharesIn)
        public
        view
        returns (uint256 amountOut)
    {
        return _quoteExitSingleExactBptIn(tokenOut, sharesIn);
    }


    function exitSingleAssetExactBptIn(
        address tokenOut,
        uint256 sharesIn,
        address to,
        uint256 amountOutMin,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256 amountOut) {
        amountOut = _exitSingleAssetExactBptIn(tokenOut, sharesIn, to, amountOutMin, deadline);
    }


    function withdrawSingle(
        address tokenOut,
        uint256 sharesIn,
        address to,
        uint256 amountOutMin,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256 amountOut) {
        amountOut = _exitSingleAssetExactBptIn(tokenOut, sharesIn, to, amountOutMin, deadline);
    }


    function _exitSingleAssetExactBptIn(
        address tokenOut,
        uint256 sharesIn,
        address to,
        uint256 amountOutMin,
        uint256 deadline
    ) internal returns (uint256 amountOut) {
        _requireDeadline(deadline);
        if (to == address(0)) revert ZeroAddress();
        if (sharesIn == 0) revert ZeroAmount();
        if (!Math.isFullBookReserves(_nativeAll())) revert NotFullBook();
        _maybeMintProtocolFee();
        amountOut = _quoteExitSingleExactBptIn(tokenOut, sharesIn);
        if (amountOut < amountOutMin) revert Slippage();
        uint8 idx = _tokenIndex(tokenOut);
        Repo.Layout storage l = Repo._layout();
        uint256 invOut = _singleExitInvOut(idx, sharesIn);
        if (invOut >= _nativeAt(idx)) revert WouldZeroReserve();
        _burnLp(msg.sender, sharesIn);
        if (l.standardExchanges[idx] != address(0)) {
            _unwrapSeShares(idx, invOut, to);
        } else {
            l.rawReserves[idx] -= invOut;
            IERC20(tokenOut).safeTransfer(to, invOut);
        }
        for (uint8 i; i < l.numTokens; ++i) {
            if (_nativeAt(i) == 0) revert WouldZeroReserve();
        }
        _snapshotKLastIfFeeOn();
        _syncVaultReserves();
        emit IUniswapV4StandardExchangeWeightedBufferHook.WithdrawSingle(msg.sender, to, tokenOut, amountOut, sharesIn, 0);
    }


    function previewWithdrawSingle(address tokenOut, uint256 sharesIn)
        public
        view
        returns (uint256 amountOut)
    {
        return previewExitSingleAssetExactBptIn(tokenOut, sharesIn);
    }


    function _singleExitInvOut(uint8 idx, uint256 sharesIn) internal view returns (uint256 invOut) {
        uint256 feeWad = _feeOracle().dexSwapFeeOfVault(address(this));
        if (feeWad >= Math.WAD) revert InvalidFeeWad();
        uint256 outS = Math.singleExitExactInAmountOut(
            _invWadAll(), Repo._layout().weights, idx, sharesIn, _previewSupplyAfterProtocolMint(), feeWad
        );
        invOut = Math.descale(outS, Repo._layout().invScales[idx]);
    }


    function _quoteExitSingleExactBptIn(address tokenOut, uint256 sharesIn)
        internal
        view
        returns (uint256 amountOut)
    {
        uint8 idx = _tokenIndex(tokenOut);
        uint256 invOut = _singleExitInvOut(idx, sharesIn);
        uint256[] memory inv = new uint256[](Repo._layout().numTokens);
        inv[idx] = invOut;
        uint256[] memory pair = _invToPairOutPreview(inv);
        amountOut = pair[idx];
    }


    function previewExitSingleAssetExactTokenOut(address tokenOut, uint256 amountOut)
        public
        view
        returns (uint256 sharesIn)
    {
        return _quoteExitSingleExactTokenOut(tokenOut, amountOut);
    }


    function exitSingleAssetExactTokenOut(
        address tokenOut,
        uint256 amountOut,
        address to,
        uint256 sharesInMax,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256 sharesIn) {
        sharesIn = _exitSingleAssetExactTokenOut(tokenOut, amountOut, to, sharesInMax, deadline);
    }


    function withdrawSingleExactOut(
        address tokenOut,
        uint256 amountOut,
        address to,
        uint256 sharesInMax,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256 sharesIn) {
        sharesIn = _exitSingleAssetExactTokenOut(tokenOut, amountOut, to, sharesInMax, deadline);
    }


    function _exitSingleAssetExactTokenOut(
        address tokenOut,
        uint256 amountOut,
        address to,
        uint256 sharesInMax,
        uint256 deadline
    ) internal returns (uint256 sharesIn) {
        _requireDeadline(deadline);
        if (to == address(0)) revert ZeroAddress();
        if (amountOut == 0) revert ZeroAmount();
        if (!Math.isFullBookReserves(_nativeAll())) revert NotFullBook();
        _maybeMintProtocolFee();
        sharesIn = _quoteExitSingleExactTokenOut(tokenOut, amountOut);
        if (sharesIn > sharesInMax) revert Slippage();
        uint8 idx = _tokenIndex(tokenOut);
        Repo.Layout storage l = Repo._layout();
        uint256 invOut;
        if (l.standardExchanges[idx] == address(0)) {
            invOut = amountOut;
        } else {
            invOut = IStandardExchangeOut(l.standardExchanges[idx]).previewExchangeOut(
                IERC20(l.standardExchanges[idx]), IERC20(tokenOut), amountOut
            );
        }
        if (invOut >= _nativeAt(idx)) revert WouldZeroReserve();
        _burnLp(msg.sender, sharesIn);
        if (l.standardExchanges[idx] != address(0)) {
            _unwrapExactTokenOut(idx, amountOut, to);
        } else {
            l.rawReserves[idx] -= invOut;
            IERC20(tokenOut).safeTransfer(to, invOut);
        }
        for (uint8 i; i < l.numTokens; ++i) {
            if (_nativeAt(i) == 0) revert WouldZeroReserve();
        }
        _snapshotKLastIfFeeOn();
        _syncVaultReserves();
        emit IUniswapV4StandardExchangeWeightedBufferHook.WithdrawSingleExactOut(msg.sender, to, tokenOut, amountOut, sharesIn, 0);
    }


    function previewWithdrawSingleExactOut(address tokenOut, uint256 amountOut)
        public
        view
        returns (uint256 sharesIn)
    {
        return previewExitSingleAssetExactTokenOut(tokenOut, amountOut);
    }


    function _quoteExitSingleExactTokenOut(address tokenOut, uint256 amountOut)
        internal
        view
        returns (uint256 sharesIn)
    {
        uint8 idx = _tokenIndex(tokenOut);
        uint256 feeWad = _feeOracle().dexSwapFeeOfVault(address(this));
        if (feeWad >= Math.WAD) revert InvalidFeeWad();
        Repo.Layout storage l = Repo._layout();
        uint256 invOut;
        if (l.standardExchanges[idx] == address(0)) {
            invOut = amountOut;
        } else {
            invOut = IStandardExchangeOut(l.standardExchanges[idx]).previewExchangeOut(
                IERC20(l.standardExchanges[idx]), IERC20(tokenOut), amountOut
            );
        }
        sharesIn = Math.singleExitExactOutSharesIn(
            _invWadAll(),
            l.weights,
            idx,
            Math.scaleToUp(invOut, l.invScales[idx]),
            _previewSupplyAfterProtocolMint(),
            feeWad
        );
    }


    function previewExitProportionalFlexible(uint256 shares, bool[] calldata receiveSeShare)
        public
        view
        returns (uint256[] memory amounts)
    {
        _validateSeShareFlags(receiveSeShare);
        uint256[] memory natives = _nativeAll();
        uint256[] memory invOut = Math.proportionalExitAmounts(shares, natives, _previewSupplyAfterProtocolMint());
        amounts = _invToEdgeOutPreview(invOut, receiveSeShare);
    }


    function exitProportionalFlexible(
        uint256 shares,
        address to,
        bool[] calldata receiveSeShare,
        uint256[] calldata amountsMin,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256[] memory amounts) {
        _requireDeadline(deadline);
        if (to == address(0)) revert ZeroAddress();
        if (shares == 0) revert ZeroAmount();
        _validateSeShareFlags(receiveSeShare);
        _maybeMintProtocolFee();
        Repo.Layout storage l = Repo._layout();
        if (amountsMin.length != l.numTokens || receiveSeShare.length != l.numTokens) {
            revert ArrayLengthMismatch();
        }
        uint256[] memory natives = _nativeAll();
        uint256[] memory invOut = Math.proportionalExitAmounts(shares, natives, _totalSupply());
        if (Math.isFullBookReserves(natives)) {
            for (uint256 i; i < l.numTokens; ++i) {
                if (invOut[i] >= natives[i]) revert WouldZeroReserve();
            }
        }
        amounts = _invToEdgeOutPreview(invOut, receiveSeShare);
        for (uint256 i; i < l.numTokens; ++i) {
            if (amounts[i] < amountsMin[i]) revert Slippage();
        }
        _burnLp(msg.sender, shares);
        for (uint8 i; i < l.numTokens; ++i) {
            if (invOut[i] == 0) continue;
            if (l.standardExchanges[i] != address(0)) {
                if (receiveSeShare[i]) {
                    IERC20(l.standardExchanges[i]).safeTransfer(to, invOut[i]);
                } else {
                    _unwrapSeShares(i, invOut[i], to);
                }
            } else {
                l.rawReserves[i] -= invOut[i];
                IERC20(l.tokens[i]).safeTransfer(to, invOut[i]);
            }
        }
        _snapshotKLastIfFeeOn();
        _syncVaultReserves();
        emit IUniswapV4StandardExchangeWeightedBufferHook.ExitFlexible(
            msg.sender, to, shares, receiveSeShare, amounts, 0
        );
    }


    function previewExitSingleAssetExactBptInFlexible(
        address tokenOut,
        uint256 sharesIn,
        bool receiveSeShare
    ) public view returns (uint256 amountOut) {
        return _quoteExitSingleExactBptInFlexible(tokenOut, sharesIn, receiveSeShare);
    }


    function exitSingleAssetExactBptInFlexible(
        address tokenOut,
        uint256 sharesIn,
        bool receiveSeShare,
        address to,
        uint256 amountOutMin,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256 amountOut) {
        amountOut = _exitSingleAssetExactBptInFlexible(
            tokenOut, sharesIn, receiveSeShare, to, amountOutMin, deadline
        );
    }


    function withdrawSingleFlexible(
        address tokenOut,
        uint256 sharesIn,
        bool receiveSeShare,
        address to,
        uint256 amountOutMin,
        uint256 deadline
    ) public onlyLiquidityOwner nonReentrant returns (uint256 amountOut) {
        amountOut = _exitSingleAssetExactBptInFlexible(
            tokenOut, sharesIn, receiveSeShare, to, amountOutMin, deadline
        );
    }


    function previewWithdrawSingleFlexible(address tokenOut, uint256 sharesIn, bool receiveSeShare)
        public
        view
        returns (uint256 amountOut)
    {
        return previewExitSingleAssetExactBptInFlexible(tokenOut, sharesIn, receiveSeShare);
    }


    function _exitSingleAssetExactBptInFlexible(
        address tokenOut,
        uint256 sharesIn,
        bool receiveSeShare,
        address to,
        uint256 amountOutMin,
        uint256 deadline
    ) internal returns (uint256 amountOut) {
        _requireDeadline(deadline);
        if (to == address(0)) revert ZeroAddress();
        if (sharesIn == 0) revert ZeroAmount();
        if (!Math.isFullBookReserves(_nativeAll())) revert NotFullBook();
        uint8 idx = _tokenIndex(tokenOut);
        if (receiveSeShare && Repo._layout().standardExchanges[idx] == address(0)) {
            revert SeShareNotBuffered();
        }
        _maybeMintProtocolFee();
        amountOut = _quoteExitSingleExactBptInFlexible(tokenOut, sharesIn, receiveSeShare);
        if (amountOut < amountOutMin) revert Slippage();
        uint256 invOut = _singleExitInvOut(idx, sharesIn);
        if (invOut >= _nativeAt(idx)) revert WouldZeroReserve();
        _burnLp(msg.sender, sharesIn);
        Repo.Layout storage l = Repo._layout();
        if (l.standardExchanges[idx] != address(0)) {
            if (receiveSeShare) {
                IERC20(l.standardExchanges[idx]).safeTransfer(to, invOut);
            } else {
                _unwrapSeShares(idx, invOut, to);
            }
        } else {
            l.rawReserves[idx] -= invOut;
            IERC20(tokenOut).safeTransfer(to, invOut);
        }
        for (uint8 i; i < l.numTokens; ++i) {
            if (_nativeAt(i) == 0) revert WouldZeroReserve();
        }
        _snapshotKLastIfFeeOn();
        _syncVaultReserves();
        emit IUniswapV4StandardExchangeWeightedBufferHook.WithdrawSingleFlexible(
            msg.sender, to, tokenOut, amountOut, receiveSeShare, sharesIn, 0
        );
    }


    function _quoteExitSingleExactBptInFlexible(address tokenOut, uint256 sharesIn, bool receiveSeShare)
        internal
        view
        returns (uint256 amountOut)
    {
        uint8 idx = _tokenIndex(tokenOut);
        if (receiveSeShare && Repo._layout().standardExchanges[idx] == address(0)) {
            revert SeShareNotBuffered();
        }
        uint256 invOut = _singleExitInvOut(idx, sharesIn);
        if (receiveSeShare || Repo._layout().standardExchanges[idx] == address(0)) {
            amountOut = invOut;
        } else {
            address se = Repo._layout().standardExchanges[idx];
            amountOut = IStandardExchangeIn(se).previewExchangeIn(
                IERC20(se), invOut, IERC20(tokenOut)
            );
        }
    }


}
