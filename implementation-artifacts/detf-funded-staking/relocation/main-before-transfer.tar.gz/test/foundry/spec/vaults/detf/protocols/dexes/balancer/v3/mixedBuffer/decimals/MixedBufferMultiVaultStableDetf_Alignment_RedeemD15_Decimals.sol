// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {TestBase_MixedBufferMultiVaultStableDetf_Decimals} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/TestBase_MixedBufferMultiVaultStableDetf_Decimals.sol";

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IRebasingClaimToken} from "contracts/interfaces/IRebasingClaimToken.sol";
import {IDETFNFTVault} from "contracts/interfaces/IDETFNFTVault.sol";
import {
    IMixedBufferMultiVaultStableDetfBonding
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/MixedBufferMultiVaultStableDetfBondingTarget.sol";
import {
    IMixedBufferMultiVaultStableDetfInfo
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/MixedBufferMultiVaultStableDetfInfoTarget.sol";

abstract contract MixedBufferMultiVaultStableDetf_Alignment_RedeemD15_Decimals is TestBase_MixedBufferMultiVaultStableDetf_Decimals {
    function setUp() public override {
        super.setUp();
        detf = _deployOpenModeDetfN(1);
        detfInfo = IMixedBufferMultiVaultStableDetfInfo(detf);
        detfBonding = IMixedBufferMultiVaultStableDetfBonding(detf);
        _bootstrapDefault(detf, alice);
    }

    function test_D15_8_tokenOutNotDetfReverts() public {
        _fundBuffer(bob, 100e18);
        vm.startPrank(bob);
        IERC20(address(rateAsset)).approve(detf, 100e18);
        (uint256 tokenId_,) =
            detfBonding.bond(IERC20(address(rateAsset)), 100e18, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours);
        vm.stopPrank();
        vm.warp(block.timestamp + DEFAULT_MIN_LOCK + 1);
        vm.prank(bob);
        detfBonding.sellPositionToDetfNft(tokenId_, 0, bob);
        uint256 claimBal_ = IRebasingClaimToken(detfInfo.rebasingClaimToken()).balanceOf(bob);
        vm.prank(bob);
        vm.expectRevert();
        detfBonding.redeemClaim(claimBal_ / 3, IERC20(address(rateAsset)), 0, bob, block.timestamp + 1 hours);
    }

    function _sellBobBuffer() internal returns (uint256 claimBal_) {
        _fundBuffer(bob, 100e18);
        vm.startPrank(bob);
        IERC20(address(rateAsset)).approve(detf, 100e18);
        (uint256 tokenId_,) =
            detfBonding.bond(IERC20(address(rateAsset)), 100e18, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours);
        vm.stopPrank();
        _warpPastUnlock(detf, tokenId_);
        vm.prank(bob);
        detfBonding.sellPositionToDetfNft(tokenId_, 0, bob);
        claimBal_ = IRebasingClaimToken(detfInfo.rebasingClaimToken()).balanceOf(bob);
        assertGt(claimBal_, 0);
    }

    function test_D15_2_smallRedeemConsumesPending() public {
        uint256 claimBal_ = _sellBobBuffer();
        uint256 redeem_ = claimBal_ / 10;
        if (redeem_ == 0) redeem_ = 1;
        IDETFNFTVault nft_ = _bondNftVault(detf);
        uint256 nftDetfBefore_ = IERC20(detf).balanceOf(address(nft_));
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-2");
        uint256 nftDetfAfter_ = IERC20(detf).balanceOf(address(nft_));
        if (nftDetfBefore_ > 0) {
            assertLe(nftDetfAfter_, nftDetfBefore_, "D15-2 pending consumed or held");
        }
    }

    function test_D15_3_pendingCoversOwed_skipsLpWithdraw() public {
        uint256 claimBal_ = _sellBobBuffer();
        IDETFNFTVault nft_ = _bondNftVault(detf);
        IERC20 lp_ = nft_.lpToken();
        _seedBondVaultRewardDetf(detf, 80 ether);
        uint256 lpBefore_ = lp_.balanceOf(address(nft_));
        uint256 origBefore_ = nft_.originalSharesOf(nft_.detfNFTId());
        uint256 redeem_ = claimBal_ / 50;
        if (redeem_ == 0) redeem_ = 1;
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-3 paid");
        assertGe(lp_.balanceOf(address(nft_)), lpBefore_, "D15-3 no LP withdraw");
        assertGe(nft_.originalSharesOf(nft_.detfNFTId()) + 1, origBefore_, "D15-3 orig except leftover compound");
    }

    function test_D15_4_shortfallResidualBuy_otherBondersUnchanged() public {
        _fundBuffer(alice, 80e18);
        vm.startPrank(alice);
        IERC20(address(rateAsset)).approve(detf, 80e18);
        (uint256 keepId_,) =
            detfBonding.bond(IERC20(address(rateAsset)), 80e18, DEFAULT_MIN_LOCK, alice, false, block.timestamp + 1 hours);
        vm.stopPrank();
        IDETFNFTVault nft_ = _bondNftVault(detf);
        uint256 keepOrig_ = nft_.originalSharesOf(keepId_);
        uint256 claimBal_ = _sellBobBuffer();
        uint256 pairBefore_ = IERC20(address(rateAsset)).balanceOf(bob);
        uint256 redeem_ = claimBal_ / 2;
        if (redeem_ == 0) redeem_ = claimBal_;
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-4 paid");
        assertEq(nft_.originalSharesOf(keepId_), keepOrig_, "D15-4 other originalShares");
        assertEq(IERC20(address(rateAsset)).balanceOf(bob), pairBefore_, "D15-4 no pair to redeemer");
    }

    /// @notice D15-5: buffer + share leftover dump; recipient DETF only.
    function test_D15_5_multiLegLeftoverDump() public {
        uint256 claimBal_ = _sellBobBuffer();
        address[] memory shares_ = detfInfo.vaultShares();
        if (shares_.length > 0) {
            uint256 funded_ = _fundVaultShares(0, alice, 40e18);
            vm.startPrank(alice);
            IERC20(shares_[0]).approve(detf, funded_);
            detfBonding.bond(IERC20(shares_[0]), funded_, DEFAULT_MIN_LOCK, alice, false, block.timestamp + 1 hours);
            vm.stopPrank();
        }
        uint256 daiBefore_ = IERC20(address(rateAsset)).balanceOf(bob);
        uint256 detfBefore_ = IERC20(detf).balanceOf(bob);
        uint256 redeem_ = claimBal_ / 4;
        if (redeem_ == 0) redeem_ = claimBal_;
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-5 DETF paid");
        assertEq(IERC20(detf).balanceOf(bob) - detfBefore_, out_);
        assertEq(IERC20(address(rateAsset)).balanceOf(bob), daiBefore_, "D15-5 no buffer to redeemer");
        assertLe(IERC20(address(rateAsset)).balanceOf(detf), 10, "buffer leftover dumped");
        if (shares_.length > 0) {
            assertLe(IERC20(shares_[0]).balanceOf(detf), 10, "share leftover dumped");
        }
    }

    function test_D15_6_lastExitRejoinsLeftover() public {
        uint256 claimBal_ = _sellBobBuffer();
        IDETFNFTVault nft_ = _bondNftVault(detf);
        uint256 pairBefore_ = IERC20(address(rateAsset)).balanceOf(bob);
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(claimBal_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-6 DETF out");
        assertEq(IERC20(address(rateAsset)).balanceOf(bob), pairBefore_, "D15-6 no pair to redeemer");
        assertGt(IERC20(nft_.lpToken()).balanceOf(address(nft_)), 0, "D15-6 leftover pair rejoined");
        assertGt(nft_.originalSharesOf(nft_.detfNFTId()), 0, "D15-6 id0 lpOut");
    }

    function test_D15_7_realizeExpansionFirst_paysFromId0Slice() public {
        (address instance_,) = _setupPolicyExpansionLive(bob, alice);
        IMixedBufferMultiVaultStableDetfBonding bonding_ = IMixedBufferMultiVaultStableDetfBonding(instance_);
        IMixedBufferMultiVaultStableDetfInfo info_ = IMixedBufferMultiVaultStableDetfInfo(instance_);
        uint256 claimBal_ = IRebasingClaimToken(info_.rebasingClaimToken()).balanceOf(bob);
        require(claimBal_ > 0, "D15-7 claim");
        _warp(6 hours);
        uint256 supplyBefore_ = IERC20(instance_).totalSupply();
        IDETFNFTVault nft_ = _bondNftVault(instance_);
        uint256 nftDetfBefore_ = IERC20(instance_).balanceOf(address(nft_));
        uint256 redeem_ = claimBal_ / 4;
        if (redeem_ == 0) redeem_ = claimBal_;
        vm.prank(bob);
        uint256 out_ = bonding_.redeemClaim(redeem_, IERC20(instance_), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-7 paid");
        if (IERC20(instance_).totalSupply() > supplyBefore_) {
            assertGe(
                IERC20(instance_).balanceOf(address(nft_)) + out_ + 1,
                nftDetfBefore_,
                "D15-7 id0 slice"
            );
        }
    }
}
