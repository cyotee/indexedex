// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IRebasingClaimToken} from "contracts/interfaces/IRebasingClaimToken.sol";
import {IDETFNFTVault} from "contracts/interfaces/IDETFNFTVault.sol";
import {
    TestBase_MultiVaultWeightedDetf
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/TestBase_MultiVaultWeightedDetf.sol";
import {
    IMultiVaultWeightedDetfBonding
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/MultiVaultWeightedDetfBondingTarget.sol";
import {
    IMultiVaultWeightedDetfInfo
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/MultiVaultWeightedDetfInfoTarget.sol";

contract MultiVaultWeightedDetf_Alignment_RedeemD15 is TestBase_MultiVaultWeightedDetf {
    function setUp() public override {
        super.setUp();
        detf = _deployOpenModeDetf("D15 MVW", "d15mvw");
        detfInfo = IMultiVaultWeightedDetfInfo(detf);
        detfBonding = IMultiVaultWeightedDetfBonding(detf);
        _bootstrapViaFirstBond(alice, 1_000e18);
    }

    function test_D15_8_tokenOutNotDetfReverts() public {
        uint256 seShares_ = _fundSeShares0(bob, 200e18);
        vm.startPrank(bob);
        seShare0.approve(detf, seShares_);
        (uint256 tokenId_,) =
            detfBonding.bond(seShare0, seShares_, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours);
        vm.stopPrank();
        _warpPastUnlock(detf, tokenId_);
        vm.prank(bob);
        detfBonding.sellPositionToDetfNft(tokenId_, 0, bob);
        uint256 claimBal_ = IRebasingClaimToken(detfInfo.rebasingClaimToken()).balanceOf(bob);
        vm.prank(bob);
        vm.expectRevert();
        detfBonding.redeemClaim(claimBal_ / 3, seShare0, 0, bob, block.timestamp + 1 hours);
    }

    function _sellBobLeg0() internal returns (uint256 claimBal_) {
        uint256 seShares_ = _fundSeShares0(bob, 200e18);
        vm.startPrank(bob);
        seShare0.approve(detf, seShares_);
        (uint256 tokenId_,) =
            detfBonding.bond(seShare0, seShares_, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours);
        vm.stopPrank();
        _warpPastUnlock(detf, tokenId_);
        vm.prank(bob);
        detfBonding.sellPositionToDetfNft(tokenId_, 0, bob);
        claimBal_ = IRebasingClaimToken(detfInfo.rebasingClaimToken()).balanceOf(bob);
        assertGt(claimBal_, 0);
    }

    function test_D15_2_smallRedeemConsumesPending() public {
        uint256 claimBal_ = _sellBobLeg0();
        uint256 redeem_ = claimBal_ / 10;
        if (redeem_ == 0) redeem_ = 1;
        IDETFNFTVault nft_ = _bondNftVault(detf);
        uint256 nftDetfBefore_ = IERC20(detf).balanceOf(address(nft_));
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-2");
        uint256 nftDetfAfter_ = IERC20(detf).balanceOf(address(nft_));
        if (nftDetfBefore_ > 0) {
            assertLe(nftDetfAfter_, nftDetfBefore_, "D15-2 pending consumed or held");
        }
    }

    function test_D15_3_pendingCoversOwed_skipsLpWithdraw() public {
        uint256 claimBal_ = _sellBobLeg0();
        IDETFNFTVault nft_ = _bondNftVault(detf);
        IERC20 lp_ = nft_.lpToken();
        _seedBondVaultRewardDetf(detf, 80 ether);
        uint256 lpBefore_ = lp_.balanceOf(address(nft_));
        uint256 origBefore_ = nft_.originalSharesOf(nft_.detfNFTId());
        uint256 redeem_ = claimBal_ / 50;
        if (redeem_ == 0) redeem_ = 1;
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-3 paid");
        assertGe(lp_.balanceOf(address(nft_)), lpBefore_, "D15-3 no LP withdraw");
        assertGe(nft_.originalSharesOf(nft_.detfNFTId()) + 1, origBefore_, "D15-3 orig except leftover compound");
    }

    function test_D15_4_shortfallResidualBuy_otherBondersUnchanged() public {
        uint256 keepShares_ = _fundSeShares0(alice, 100e18);
        vm.startPrank(alice);
        seShare0.approve(detf, keepShares_);
        (uint256 keepId_,) =
            detfBonding.bond(seShare0, keepShares_, DEFAULT_MIN_LOCK, alice, false, block.timestamp + 1 hours);
        vm.stopPrank();
        IDETFNFTVault nft_ = _bondNftVault(detf);
        uint256 keepOrig_ = nft_.originalSharesOf(keepId_);
        uint256 claimBal_ = _sellBobLeg0();
        uint256 pairBefore_ = seShare0.balanceOf(bob);
        uint256 redeem_ = claimBal_ / 2;
        if (redeem_ == 0) redeem_ = claimBal_;
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-4 paid");
        assertEq(nft_.originalSharesOf(keepId_), keepOrig_, "D15-4 other originalShares");
        assertEq(seShare0.balanceOf(bob), pairBefore_, "D15-4 no pair to redeemer");
    }

    /// @notice D15-5: snapshot leftover legs; dump largest leftover; recipient DETF only.
    function test_D15_5_multiLegLeftoverDump() public {
        uint256 claimBal_ = _sellBobLeg0();
        uint256 s0Before_ = seShare0.balanceOf(bob);
        uint256 s1Before_ = seShare1.balanceOf(bob);
        uint256 detfBefore_ = IERC20(detf).balanceOf(bob);
        uint256 redeem_ = claimBal_ / 4;
        if (redeem_ == 0) redeem_ = claimBal_;
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(redeem_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-5 DETF paid");
        assertEq(IERC20(detf).balanceOf(bob) - detfBefore_, out_);
        assertEq(seShare0.balanceOf(bob), s0Before_, "D15-5 no se0 to redeemer");
        assertEq(seShare1.balanceOf(bob), s1Before_, "D15-5 no se1 to redeemer");
        assertLe(seShare0.balanceOf(detf), 10, "largest leftover dumped or rejoined");
        assertLe(seShare1.balanceOf(detf), 10, "second leftover dumped or rejoined");
    }

    function test_D15_6_lastExitRejoinsLeftover() public {
        uint256 claimBal_ = _sellBobLeg0();
        IDETFNFTVault nft_ = _bondNftVault(detf);
        uint256 pairBefore_ = seShare0.balanceOf(bob);
        vm.prank(bob);
        uint256 out_ = detfBonding.redeemClaim(claimBal_, IERC20(detf), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-6 DETF out");
        assertEq(seShare0.balanceOf(bob), pairBefore_, "D15-6 no pair to redeemer");
        assertGt(IERC20(nft_.lpToken()).balanceOf(address(nft_)), 0, "D15-6 leftover pair rejoined");
        assertGt(nft_.originalSharesOf(nft_.detfNFTId()), 0, "D15-6 id0 lpOut");
    }

    function test_D15_7_realizeExpansionFirst_paysFromId0Slice() public {
        (address instance_,) = _setupPolicyExpansionLive(bob, alice);
        IMultiVaultWeightedDetfBonding bonding_ = IMultiVaultWeightedDetfBonding(instance_);
        IMultiVaultWeightedDetfInfo info_ = IMultiVaultWeightedDetfInfo(instance_);
        uint256 claimBal_ = IRebasingClaimToken(info_.rebasingClaimToken()).balanceOf(bob);
        require(claimBal_ > 0, "D15-7 claim");
        _warp(6 hours);
        uint256 supplyBefore_ = IERC20(instance_).totalSupply();
        IDETFNFTVault nft_ = _bondNftVault(instance_);
        uint256 nftDetfBefore_ = IERC20(instance_).balanceOf(address(nft_));
        uint256 redeem_ = claimBal_ / 4;
        if (redeem_ == 0) redeem_ = claimBal_;
        vm.prank(bob);
        uint256 out_ = bonding_.redeemClaim(redeem_, IERC20(instance_), 0, bob, block.timestamp + 1 hours);
        assertGt(out_, 0, "D15-7 paid");
        if (IERC20(instance_).totalSupply() > supplyBefore_) {
            assertGe(
                IERC20(instance_).balanceOf(address(nft_)) + out_ + 1,
                nftDetfBefore_,
                "D15-7 id0 slice"
            );
        }
    }
}
