// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IERC20Events} from "@crane/contracts/interfaces/IERC20Events.sol";
import {Math} from "@crane/contracts/utils/Math.sol";
import {IStandardExchangeOut} from "@crane/contracts/interfaces/IStandardExchangeOut.sol";
import {SimpleMintableERC20} from "contracts/test/stubs/SimpleMintableERC20.sol";
import {IUniswapV4SeBufferHook} from "contracts/hooks/uniswap/v4/interfaces/IUniswapV4SeBufferHook.sol";
import {IStandardExchangeIn} from "@crane/contracts/interfaces/IStandardExchangeIn.sol";
import {IRebasingClaimToken, IRebasingClaimTokenSupply} from "contracts/interfaces/IRebasingClaimToken.sol";
import {IDETFNFTVault} from "contracts/interfaces/IDETFNFTVault.sol";
import {IDetfErrors} from "contracts/interfaces/IDetfErrors.sol";
import {IDetfNftReserveDonation} from "contracts/vaults/detf/common/bondNft/IDetfReserveDonation.sol";
import {UniswapV4Detf_ClaimBase} from
    "test/foundry/spec/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4Detf_ClaimBase.sol";

// tag::RebasingClaimToken_Accounting[]
/// @notice Live valuation, fractional claim principal, and zero-result mint regressions.
/// @dev Uses production DETF/claim/NFT/hook proxies. The inherited owner-mediated
///      sale helper establishes claim ownership; donation, close and redeem use users.
contract RebasingClaimToken_Accounting is UniswapV4Detf_ClaimBase {
    uint256 private constant INTERNAL_SCALE = 1e9;
    uint256 private constant INTERNAL_UNIT = 1e27;

    function test_transfer_zeroAmount_beforeFirstClaim() public {
        _assertZeroTransfers();
    }

    function test_transfer_zeroAmount_withLiveBacking() public {
        _seedClaims();
        _donateFreeDetf();
        _assertZeroTransfers();
    }

    function test_accounting_fractionalOnlySupply_remainsOutstanding() public {
        uint256 firstId_ = _seedClaims();
        _donateFreeDetf();
        IRebasingClaimToken claim_ = _claimTok();
        uint256 amount_ = claim_.balanceOf(detfUser);
        uint256 remaining_ = claim_.totalShares() * INTERNAL_SCALE
            - Math.mulDiv(amount_, INTERNAL_UNIT, claim_.redemptionRate());
        assertGt(remaining_, 0, "real conversion leaves fractional ownership");
        assertLt(remaining_, INTERNAL_SCALE, "less than one external share");
        vm.prank(detf);
        claim_.burnShares(amount_, detfUser, false);
        assertEq(claim_.totalShares(), 0, "external share view rounds down");
        assertTrue(IRebasingClaimTokenSupply(address(claim_)).hasOutstandingShares(), "internal ownership remains");
        uint256 principalBefore_ = _nft().originalSharesOf(0);
        uint256 feeBefore_ = _nft().originalSharesOf(1);
        _close(firstId_);
        assertGt(_nft().originalSharesOf(0), principalBefore_, "accrual belongs to existing fractional claims");
        assertEq(_nft().originalSharesOf(1), feeBefore_, "live fractional claims are not treated as unissued");
        _assertOverBalanceTransferRejected(claim_);
        _purchaseAfterFractionalSupply(claim_);
    }

    function _assertOverBalanceTransferRejected(IRebasingClaimToken claim_) private {
        address recipient_ = makeAddr("fractional overdraw recipient");
        uint256 balance_ = claim_.balanceOf(detfUser);
        assertGt(balance_, 0);
        vm.prank(detfUser);
        vm.expectRevert(abi.encodeWithSelector(IDetfErrors.InsufficientBalance.selector, balance_ + 1, balance_));
        claim_.transfer(recipient_, balance_ + 1);
        assertEq(claim_.balanceOf(detfUser), balance_, "sender balance unchanged");
        assertEq(claim_.balanceOf(recipient_), 0, "recipient gets no ownership");
    }

    function _purchaseAfterFractionalSupply(IRebasingClaimToken claim_) private {
        address buyer_ = makeAddr("fractional supply buyer");
        uint256 amount_ = IERC20(detf).balanceOf(detfUser) / 10;
        uint256 backingBefore_ = _nft().originalSharesOf(0);
        uint256 lockedBefore_ = _nft().originalSharesOf(1);
        assertGt(amount_, 0);
        vm.startPrank(detfUser);
        IERC20(detf).approve(detf, amount_);
        uint256 minted_ = IStandardExchangeIn(detf).exchangeIn(
            IERC20(detf), amount_, IERC20(address(claim_)), 0, buyer_, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        assertGt(minted_, 0, "fractional ownership does not prevent new purchases");
        assertGt(claim_.balanceOf(buyer_), 0, "buyer receives redeemable ownership");
        assertGt(claim_.balanceOf(detfUser), 0, "prior fractional holder keeps its backing");
        assertGt(_nft().originalSharesOf(0), backingBefore_, "purchase contributes backing");
        assertEq(_nft().originalSharesOf(1), lockedBefore_, "locked fee principal unchanged");
        uint256 redeemAmount_ = claim_.balanceOf(buyer_) / 2;
        vm.prank(buyer_);
        assertGt(claim_.redeem(redeemAmount_, buyer_, false), 0, "new fractional claims redeem");
        assertEq(_nft().originalSharesOf(1), lockedBefore_);
    }

    function _assertZeroTransfers() private {
        IRebasingClaimToken claim_ = _claimTok();
        address recipient_ = makeAddr("zero transfer recipient");
        address spender_ = makeAddr("zero transfer spender");
        uint256 supplyBefore_ = claim_.totalShares();
        uint256 sharesBefore_ = claim_.sharesOf(detfUser);
        uint256 recipientBefore_ = claim_.sharesOf(recipient_);

        vm.expectEmit(true, true, false, true, address(claim_));
        emit IERC20Events.Transfer(detfUser, recipient_, 0);
        vm.prank(detfUser);
        assertTrue(claim_.transfer(recipient_, 0), "zero transfer succeeds");

        vm.expectEmit(true, true, false, true, address(claim_));
        emit IERC20Events.Transfer(detfUser, recipient_, 0);
        vm.prank(spender_);
        assertTrue(claim_.transferFrom(detfUser, recipient_, 0), "zero transferFrom needs no allowance");

        assertEq(claim_.totalShares(), supplyBefore_, "claim supply unchanged");
        assertEq(claim_.sharesOf(detfUser), sharesBefore_, "sender ownership unchanged");
        assertEq(claim_.sharesOf(recipient_), recipientBefore_, "recipient ownership unchanged");
        assertEq(claim_.allowance(detfUser, spender_), 0, "allowance unchanged");
    }

    struct RedeemControl {
        uint256 amount;
        uint256 rate;
        uint256 internalShares;
        uint256 originalReleased;
        uint256 legacyReleased;
        uint256 preview;
    }

    /// @notice A rate snapshot must not freeze balances after a same-block DETF donation.
    function test_accounting_sameBlockDonation_updatesLiveRateAndBalance() public {
        _seedClaims();
        IRebasingClaimToken claim_ = _claimTok();
        claim_.updateRedemptionRate();
        uint256 rateBefore_ = claim_.redemptionRate();
        uint256 blockBefore_ = block.number;

        _donateFreeDetf();

        assertEq(block.number, blockBefore_, "backing changed within the cached block");
        uint256 supply_ = claim_.totalSupply();
        uint256 rateExpected_ = Math.mulDiv(supply_, 1e18, claim_.totalShares());
        assertGt(rateExpected_, rateBefore_, "donation changed DETF backing per claim share");
        assertEq(claim_.redemptionRate(), rateExpected_, "rate uses live backing");
        assertEq(
            claim_.balanceOf(detfUser),
            Math.mulDiv(claim_.sharesOf(detfUser), rateExpected_, 1e18),
            "holder balance uses live backing"
        );
    }

    /// @notice A same-block snapshot cannot alter the shares charged for a later redemption.
    function test_accounting_sameBlockDonation_redeemUsesLiveRate() public {
        _seedClaims();
        IRebasingClaimToken claim_ = _claimTok();
        claim_.updateRedemptionRate();
        uint256 rateBefore_ = claim_.redemptionRate();
        uint256 blockBefore_ = block.number;
        _donateFreeDetf();
        uint256 liveRate_ = Math.mulDiv(claim_.totalSupply(), 1e18, claim_.totalShares());
        assertGt(liveRate_, rateBefore_, "backing increased");
        uint256 amount_ = claim_.totalSupply() / 1000;
        uint256 expectedShares_ = Math.mulDiv(amount_, INTERNAL_UNIT, liveRate_) / INTERNAL_SCALE;
        uint256 sharesBefore_ = claim_.sharesOf(detfUser);
        uint256 balanceBefore_ = IERC20(detf).balanceOf(detfUser);
        uint256 expectedOut_ = claim_.previewRedeem(amount_);
        assertLe(expectedOut_, Math.mulDiv(Math.mulDiv(amount_, INTERNAL_UNIT, liveRate_), liveRate_, INTERNAL_UNIT));

        vm.prank(detfUser);
        uint256 out_ = claim_.redeem(amount_, detfUser, false);

        assertEq(block.number, blockBefore_, "redeem stays in snapshot block");
        assertEq(out_, expectedOut_, "redeem pays live quote after reserve LP rounding");
        assertEq(IERC20(detf).balanceOf(detfUser) - balanceBefore_, out_, "recipient delta");
        assertApproxEqAbs(
            sharesBefore_ - claim_.sharesOf(detfUser), expectedShares_, 1, "live-rate share debit"
        );
    }

    /// @notice Fractions of internal shares must contribute to released original principal.
    function test_accounting_fractionalShares_releaseFullPrecisionPrincipal() public {
        uint256 firstId_ = _seedClaims();
        _close(firstId_);
        IRebasingClaimToken claim_ = _claimTok();
        uint256 totalInternal_ = claim_.totalShares() * INTERNAL_SCALE;
        assertGt(_nft().originalSharesOf(0), claim_.totalShares(), "protocol acquired additional principal");

        totalInternal_ = _assertPrecisionRedeem(totalInternal_);
        assertGt(totalInternal_ % INTERNAL_SCALE, 0, "ordinary redeem leaves fractional total shares");
        // The second redemption also exercises a fractional denominator, without storage writes.
        _assertPrecisionRedeem(totalInternal_);
    }

    function test_accounting_preClaimBacking_locksToFeeBondAndFirstPurchaseSucceeds() public {
        _setPfc(detf);
        (uint256 firstId_,) = _firstBond(1000 ether);
        _firstBond(40 ether);
        _warpMature(firstId_);
        _close(firstId_);
        IRebasingClaimToken claim_ = _claimTok();
        assertEq(claim_.totalShares(), 0, "no claim ownership established");
        uint256 locked_ = _nft().originalSharesOf(1);
        assertGt(locked_, 0, "pre-claim protocol backing belongs to fee bond");
        assertEq(_nft().originalSharesOf(0), 0, "no unissued claim backing");
        assertFalse(IRebasingClaimTokenSupply(address(claim_)).hasOutstandingShares());
        assertGt(_nft().effectiveSharesOf(1), locked_, "locked principal earns in addition to fee weight");
        uint256 balanceBefore_ = IERC20(detf).balanceOf(detfUser);
        uint256 lpBefore_ = _lpOf(detf).balanceOf(address(_nft()));
        uint256 amount_ = balanceBefore_ / 10;
        assertGt(amount_, 0, "holder has DETF to purchase claims");
        vm.prank(detfUser);
        IERC20(detf).approve(detf, amount_);

        vm.prank(detfUser);
        uint256 minted_ = IStandardExchangeIn(detf).exchangeIn(
            IERC20(detf), amount_, IERC20(address(claim_)), 0, detfUser, false, block.timestamp + 1 hours
        );

        assertGt(minted_, 0, "first purchase succeeds");
        assertEq(IERC20(detf).balanceOf(detfUser), balanceBefore_ - amount_, "purchase funded");
        assertGt(_lpOf(detf).balanceOf(address(_nft())), lpBefore_, "new physical backing");
        assertEq(_nft().originalSharesOf(1), locked_, "old backing stays locked");
        assertEq(claim_.totalShares(), _nft().originalSharesOf(0), "first buyer receives only new principal");
        assertTrue(IRebasingClaimTokenSupply(address(claim_)).hasOutstandingShares());

        uint256 assetsBefore_ = _nft().convertToAssets(locked_);
        uint256 redeemAmount_ = claim_.balanceOf(detfUser) / 2;
        vm.prank(detfUser);
        uint256 paid_ = claim_.redeem(redeemAmount_, detfUser, false);
        assertGt(paid_, 0, "claims can redeem");
        assertEq(_nft().originalSharesOf(1), locked_, "redemption cannot debit locked principal");
        assertGe(_nft().convertToAssets(locked_), assetsBefore_, "locked reserve assets preserved");
        _assertFeePrincipalCannotExit(locked_);
    }

    function test_accounting_lockedFeeBacking_earnsAdditionalRewards() public {
        _setPfc(detf);
        (uint256 firstId_,) = _firstBond(1000 ether);
        _firstBond(40 ether);
        _warpMature(firstId_);
        _close(firstId_);
        IDETFNFTVault nft_ = _nft();
        uint256 locked_ = nft_.originalSharesOf(1);
        assertGt(locked_, 0);
        address feeOwner_ = nft_.ownerOf(1);
        assertGt(feeOwner_.code.length, 0, "production fee collector owns the standing bond");
        address keeper_ = makeAddr("standing rewards keeper");
        vm.prank(keeper_);
        nft_.claimRewards(1, feeOwner_);
        uint256 reward_ = IERC20(detf).balanceOf(detfUser) / 4;
        assertGt(reward_, 0);
        vm.prank(detfUser);
        IERC20(detf).transfer(address(nft_), reward_);
        uint256 earned_ = nft_.pendingRewards(1);
        uint256 ordinaryFeeOnly_ = Math.mulDiv(reward_, nft_.effectiveSharesOf(1) - locked_, nft_.totalShares());
        assertGt(earned_, ordinaryFeeOnly_, "locked capital receives its own reward allocation");
        uint256 before_ = IERC20(detf).balanceOf(feeOwner_);
        vm.prank(keeper_);
        vm.expectRevert(abi.encodeWithSignature("NotBondHolder(address,address)", feeOwner_, keeper_));
        nft_.claimRewards(1, keeper_);
        vm.prank(keeper_);
        assertEq(nft_.claimRewards(1, feeOwner_), earned_, "keeper pays rewards to the fee collector");
        assertEq(IERC20(detf).balanceOf(feeOwner_) - before_, earned_);
        assertEq(nft_.originalSharesOf(1), locked_, "collecting rewards never releases principal");
    }

    function _assertFeePrincipalCannotExit(uint256 locked_) private {
        IDETFNFTVault nft_ = _nft();
        address feeOwner_ = nft_.ownerOf(1);
        bytes memory restricted_ = abi.encodeWithSignature("DETFNFTRestricted(uint256)", 1);
        vm.prank(detf);
        vm.expectRevert(restricted_);
        nft_.sellPositionToDetfNft(1, feeOwner_, feeOwner_);
        vm.prank(detf);
        vm.expectRevert(restricted_);
        nft_.redeemPosition(1, feeOwner_, block.timestamp + 1 hours);
        vm.prank(detf);
        vm.expectRevert(restricted_);
        nft_.retireMaturePosition(1, feeOwner_);
        vm.prank(detf);
        vm.expectRevert(restricted_);
        nft_.removeFromDETFNFT(1, locked_);
        assertEq(nft_.originalSharesOf(1), locked_, "all principal exit paths reject standing bond");
    }

    /// @notice A positive contribution that rounds to zero internal ownership cannot mint.
    function test_accounting_zeroInternalMint_revertsWithoutChangingClaims() public {
        uint256 firstId_ = _seedClaims();
        _close(firstId_);
        IRebasingClaimToken claim_ = _claimTok();
        uint256 totalBefore_ = claim_.totalShares();
        uint256 principalBefore_ = _nft().originalSharesOf(0);
        uint256 backingSnapshot_ = totalBefore_ * INTERNAL_SCALE + 1;
        assertGt(backingSnapshot_, totalBefore_ * INTERNAL_SCALE, "one asset buys no internal share");
        uint256 balanceBefore_ = claim_.balanceOf(detfUser);

        vm.prank(detf);
        vm.expectRevert(IDetfErrors.ZeroAmount.selector);
        claim_.mintFromNFTSale(1, backingSnapshot_, detfUser);

        assertEq(claim_.totalShares(), totalBefore_, "no supply mutation");
        assertEq(claim_.balanceOf(detfUser), balanceBefore_, "no balance mutation");
        assertEq(_nft().originalSharesOf(0), principalBefore_, "principal unchanged");
    }

    /// @notice A zero-valued redemption cannot begin a principal unwind.
    function test_accounting_zeroValueRedeem_preservesPrincipalAndOwnership() public {
        _seedClaims();
        _sellPairToReduceClaimValue();
        IRebasingClaimToken claim_ = _claimTok();
        assertGt(claim_.redemptionRate(), 0, "backing has a positive rate");
        assertEq(claim_.previewRedeem(1), 0, "one token wei rounds to no payout");
        uint256 principal_ = _nft().originalSharesOf(0);
        uint256 shares_ = claim_.totalShares();
        uint256 converted_ = Math.mulDiv(1, INTERNAL_UNIT, claim_.redemptionRate());
        assertGt(Math.mulDiv(converted_, principal_, shares_ * INTERNAL_SCALE), 0, "positive principal conversion");
        uint256 balance_ = claim_.balanceOf(detfUser);
        vm.prank(detfUser);
        vm.expectRevert(IDetfErrors.ZeroAmount.selector);
        claim_.redeem(1, detfUser, false);
        assertEq(_nft().originalSharesOf(0), principal_, "principal unchanged");
        assertEq(claim_.totalShares(), shares_, "ownership unchanged");
        assertEq(claim_.balanceOf(detfUser), balance_, "balance unchanged");
    }

    function _sellPairToReduceClaimValue() private {
        IUniswapV4SeBufferHook hook_ = IUniswapV4SeBufferHook(detfInfo.hook());
        IERC20 pair_ = _leadPairOf(detf);
        uint256[] memory reserves_ = hook_.previewExitProportional(IERC20(address(hook_)).totalSupply());
        address[] memory tokens_ = hook_.tokens();
        uint256 amount_;
        for (uint256 i; i < tokens_.length; ++i) {
            if (tokens_[i] == address(pair_)) amount_ = reserves_[i] * 100;
        }
        assertGt(amount_, 0);
        SimpleMintableERC20(address(pair_)).mint(detfUser, amount_);
        vm.startPrank(detfUser);
        pair_.approve(address(hook_), amount_);
        IStandardExchangeIn(address(hook_)).exchangeIn(
            pair_, amount_, IERC20(detf), 1, detfUser, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
    }

    /// @notice Ordinary trading can leave positive claim ownership with no whole DETF wei extractable.
    function test_accounting_zeroZap_preservesZeroValuationAndRejectsExactOutput() public {
        _seedZeroZapClaims();
        IRebasingClaimToken claim_ = _claimTok();
        assertEq(claim_.totalSupply(), 0, "no extractable DETF backing");
        assertEq(claim_.redemptionRate(), 0, "zero backing is not a unit-rate bootstrap");
        assertEq(claim_.balanceOf(detfUser), 0, "positive shares have zero token balance");
        assertEq(claim_.previewRedeem(1), 0, "no fabricated redeem value");
        vm.expectRevert(IStandardExchangeOut.ExchangeOutNotAvailable.selector);
        claim_.previewExchangeOut(IERC20(address(claim_)), IERC20(detf), 1);
        uint256 sharesBefore_ = claim_.sharesOf(detfUser);
        uint256 detfBefore_ = IERC20(detf).balanceOf(detfUser);
        vm.prank(detfUser);
        vm.expectRevert(IStandardExchangeOut.ExchangeOutNotAvailable.selector);
        claim_.exchangeOut(
            IERC20(address(claim_)), type(uint256).max, IERC20(detf), 1,
            detfUser, false, block.timestamp + 1 hours
        );
        assertEq(claim_.sharesOf(detfUser), sharesBefore_, "unavailable output preserves shares");
        assertEq(IERC20(detf).balanceOf(detfUser), detfBefore_, "no unbacked DETF payout");
    }

    /// @notice A zero-balance mint rolls back the internal shares already tentatively issued.
    function test_accounting_zeroZap_mintRevertsWithoutIssuingShares() public {
        _seedZeroZapClaims();
        IRebasingClaimToken claim_ = _claimTok();
        uint256 sharesBefore_ = claim_.totalShares();
        uint256 holderBefore_ = claim_.sharesOf(detfUser);
        uint256 principalBefore_ = _nft().originalSharesOf(0);
        // Exercise the real owner-only mint boundary, as in the existing dust-mint
        // regression. This amount makes the share result positive before valuation.
        assertGt(principalBefore_, 0, "positive mint input and denominator");
        assertGt(sharesBefore_, 0, "equal input and backing produce positive external shares");
        vm.prank(detf);
        vm.expectRevert(IDetfErrors.ZeroAmount.selector);
        claim_.mintFromNFTSale(principalBefore_, detfUser);
        assertEq(claim_.totalShares(), sharesBefore_, "tentative share mint rolled back");
        assertEq(claim_.sharesOf(detfUser), holderBefore_, "recipient shares unchanged");
        assertEq(_nft().originalSharesOf(0), principalBefore_, "backing unchanged");
    }

    function _seedZeroZapClaims() private {
        _firstBond(1_500);
        (uint256 soldId_,) = _firstBond(40);
        _warpMature(soldId_);
        (, uint256 minted_) = _d10SellToClaimOn(detf, soldId_, detfUser);
        assertGt(minted_, 0, "claims established at positive value");
        IUniswapV4SeBufferHook hook_ = IUniswapV4SeBufferHook(detfInfo.hook());
        IERC20 pair_ = _leadPairOf(detf);
        address[] memory tokens_ = hook_.tokens();
        uint256[] memory reserves_ = hook_.previewExitProportional(IERC20(address(hook_)).totalSupply());
        uint256 rawReserve_;
        uint256 pairReserve_;
        for (uint256 i; i < tokens_.length; ++i) {
            if (tokens_[i] == detf) rawReserve_ = reserves_[i];
            else pairReserve_ = reserves_[i];
        }
        // The CP exact-input quote leaves one raw wei at this bounded input.
        // Use measured live reserves rather than writing any pool state.
        uint256 amount_ = pairReserve_ * (rawReserve_ + 1) * 2;
        SimpleMintableERC20(address(pair_)).mint(detfUser, amount_);
        vm.startPrank(detfUser);
        pair_.approve(address(hook_), amount_);
        IStandardExchangeIn(address(hook_)).exchangeIn(
            pair_, amount_, IERC20(detf), 1, detfUser, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        uint256 principal_ = _nft().originalSharesOf(0);
        uint256 lp_ = _nft().convertToAssets(principal_);
        assertGt(_claimTok().totalShares(), 0, "outstanding real claim ownership");
        assertGt(principal_, 0, "id0 retains original principal");
        assertGt(lp_, 0, "physical LP remains represented");
        assertEq(detfInfo.previewClaimLiquidity(lp_), 0, "live zapout boundary established");
        assertEq(_nft().pendingRewards(0), 0, "no pending reward backing");
    }

    function _seedClaims() private returns (uint256 firstId_) {
        (firstId_,) = _firstBond(1000 ether);
        (uint256 soldId_,) = _firstBond(40 ether);
        _warpMature(soldId_);
        (, uint256 minted_) = _d10SellToClaimOn(detf, soldId_, detfUser);
        assertGt(minted_, 0, "production sale establishes claims");
    }

    function _donateFreeDetf() private {
        uint256 amount_ = IERC20(detf).balanceOf(detfUser) / 2;
        assertGt(amount_, 0, "bond holder has free DETF");
        address nft_ = address(_nft());
        vm.startPrank(detfUser);
        IERC20(detf).approve(nft_, amount_);
        IDetfNftReserveDonation(nft_).donate(IERC20(detf), amount_, 0, false, block.timestamp + 1 hours);
        vm.stopPrank();
    }

    function _close(uint256 tokenId_) private {
        uint256[] memory mins_ = _minOutOf(detf);
        vm.prank(detfUser);
        detfInfo.closeBondMature(tokenId_, mins_, detfUser, block.timestamp + 1 hours);
    }

    function _assertPrecisionRedeem(uint256 totalInternal_) private returns (uint256) {
        IRebasingClaimToken claim_ = _claimTok();
        RedeemControl memory c_;
        c_.rate = claim_.redemptionRate();
        c_.amount = claim_.balanceOf(detfUser) / 1000;
        uint256 original_ = _nft().originalSharesOf(0);
        assertEq(claim_.totalShares(), totalInternal_ / INTERNAL_SCALE, "tracked total matches public shares");
        // Select a real token amount where flooring external shares would change the result.
        for (uint256 i; i < 64; ++i) {
            c_.internalShares = Math.mulDiv(c_.amount, INTERNAL_UNIT, c_.rate);
            c_.originalReleased = Math.mulDiv(c_.internalShares, original_, totalInternal_);
            c_.legacyReleased = Math.mulDiv(
                c_.internalShares / INTERNAL_SCALE, original_, totalInternal_ / INTERNAL_SCALE
            );
            if (c_.originalReleased != c_.legacyReleased && c_.internalShares % INTERNAL_SCALE != 0) break;
            ++c_.amount;
        }
        assertGt(c_.internalShares % INTERNAL_SCALE, 0, "fractional internal shares selected");
        assertTrue(c_.originalReleased != c_.legacyReleased, "fixture distinguishes premature truncation");
        c_.preview = claim_.previewRedeem(c_.amount);

        vm.expectEmit(true, true, false, true, address(claim_));
        emit IRebasingClaimToken.Redeemed(detfUser, detfUser, c_.amount, c_.originalReleased, c_.preview);
        vm.prank(detfUser);
        uint256 out_ = claim_.redeem(c_.amount, detfUser, false);

        assertEq(out_, c_.preview, "redemption output remains preview-compatible");
        uint256 remaining_ = totalInternal_ - c_.internalShares;
        assertEq(claim_.totalShares(), remaining_ / INTERNAL_SCALE, "tracked burn matches public total");
        return remaining_;
    }
}
// end::RebasingClaimToken_Accounting[]
