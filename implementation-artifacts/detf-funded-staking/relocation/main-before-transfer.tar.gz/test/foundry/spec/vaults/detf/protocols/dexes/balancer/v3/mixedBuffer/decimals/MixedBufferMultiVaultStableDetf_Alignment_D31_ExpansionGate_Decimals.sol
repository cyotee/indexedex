// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {TestBase_MixedBufferMultiVaultStableDetf_Decimals} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/TestBase_MixedBufferMultiVaultStableDetf_Decimals.sol";

import {ThresholdMode} from "contracts/vaults/detf/common/core/DETFThresholdPolicy.sol";
import {
    IMixedBufferMultiVaultStableDetfInfo
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/MixedBufferMultiVaultStableDetfInfoTarget.sol";

abstract contract MixedBufferMultiVaultStableDetf_Alignment_D31_ExpansionGate_Decimals is TestBase_MixedBufferMultiVaultStableDetf_Decimals {
    function test_D31_4_openDoesNotExpandOnCompound() public {
        detf = _deployOpenModeDetfN(1);
        detfInfo = IMixedBufferMultiVaultStableDetfInfo(detf);
        _bootstrapDefault(detf, alice);
        uint256 last_ = detfInfo.lastExpansionTimestamp();
        vm.warp(block.timestamp + 30 days);
        assertEq(uint8(detfInfo.thresholdMode()), uint8(ThresholdMode.Open));
        assertEq(detfInfo.lastExpansionTimestamp(), last_, "D31-4");
    }
}
