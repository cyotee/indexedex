// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {TestBase_MultiVaultWeightedDetf_Decimals} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/TestBase_MultiVaultWeightedDetf_Decimals.sol";

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IRebasingClaimToken} from "contracts/interfaces/IRebasingClaimToken.sol";
import {
    MultiVaultWeightedDetfRepo
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/MultiVaultWeightedDetfRepo.sol";

/// @notice Real claim path: sellNFT mints claim; redeemClaim pays configured rateAsset from BPT unwind.
abstract contract MultiVaultWeightedDetf_Claim_Decimals is TestBase_MultiVaultWeightedDetf_Decimals {
    function test_claimToken_wiredOnDeploy() public view {
        address claim_ = detfInfo.rebasingClaimToken();
        assertTrue(claim_ != address(0), "claim token wired");
        assertEq(IRebasingClaimToken(claim_).detf(), detf, "claim points at detf");
    }

    function test_sellNFT_mintsClaim_thenRedeemToRateAsset() public {
        (uint256 tokenId_, uint256 bptPrincipal_) = _goLiveViaBptBond(detf, alice, 1_500e18);
        assertTrue(bptPrincipal_ > 0, "bpt principal");

        IRebasingClaimToken claim_ = IRebasingClaimToken(detfInfo.rebasingClaimToken());
        uint256 claimBefore_ = claim_.balanceOf(alice);

        _warpPastUnlock(detf, tokenId_);
        vm.prank(alice);
        uint256 minted_ = detfBonding.sellPositionToDetfNft(tokenId_, 0, alice);
        assertTrue(minted_ > 0, "claim minted");
        assertEq(claim_.balanceOf(alice) - claimBefore_, minted_, "claim balance");

        uint256 detfBefore_ = IERC20(detf).balanceOf(alice);
        uint256 claimAmt_ = claim_.balanceOf(alice);
        assertTrue(claimAmt_ > 0, "has claim");

        // D15: redeem half of claim for DETF only
        uint256 redeemAmt_ = claimAmt_ / 2;
        if (redeemAmt_ == 0) redeemAmt_ = claimAmt_;

        vm.prank(alice);
        uint256 out_ =
            detfBonding.redeemClaim(redeemAmt_, IERC20(detf), 0, alice, block.timestamp + 1 hours);

        assertTrue(out_ > 0, "DETF payout");
        assertEq(IERC20(detf).balanceOf(alice) - detfBefore_, out_, "DETF received");
        assertTrue(claim_.balanceOf(alice) < claimAmt_, "claim burned");
        _assertNoFreeInventory(detf);
    }

    function test_redeemClaim_unconfiguredRateAsset_reverts() public {
        (uint256 tokenId_,) = _goLiveViaBptBond(detf, alice, 800e18);
        _warpPastUnlock(detf, tokenId_);
        vm.prank(alice);
        detfBonding.sellPositionToDetfNft(tokenId_, 0, alice);

        address junk = address(uint160(uint256(keccak256("junkRate"))));
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(MultiVaultWeightedDetfRepo.InvalidRoute.selector, detfInfo.rebasingClaimToken(), junk)
        );
        detfBonding.redeemClaim(1e18, IERC20(junk), 0, alice, block.timestamp + 1 hours);
    }

    function test_redeemClaim_withoutClaimInventory_reverts() public {
        _goLiveViaBptBond(detf, bob, 500e18);
        // alice has no claim tokens
        vm.prank(alice);
        vm.expectRevert();
        detfBonding.redeemClaim(1e18, rateAsset0, 0, alice, block.timestamp + 1 hours);
    }
}
