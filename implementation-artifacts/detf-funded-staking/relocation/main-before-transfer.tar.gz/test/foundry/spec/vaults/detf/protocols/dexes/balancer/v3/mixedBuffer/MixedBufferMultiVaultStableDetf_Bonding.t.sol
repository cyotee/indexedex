// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IStandardExchangeIn} from "@crane/contracts/interfaces/IStandardExchangeIn.sol";
import {
    TestBase_MixedBufferMultiVaultStableDetf
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/TestBase_MixedBufferMultiVaultStableDetf.sol";
import {
    IMixedBufferMultiVaultStableDetfInfo
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/MixedBufferMultiVaultStableDetfInfoTarget.sol";
import {
    IMixedBufferMultiVaultStableDetfBonding
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/mixedBuffer/MixedBufferMultiVaultStableDetfBondingTarget.sol";
import {IDETFNFTVault} from "contracts/interfaces/IDETFNFTVault.sol";

contract MixedBufferMultiVaultStableDetf_Bonding_Test is TestBase_MixedBufferMultiVaultStableDetf {
    function setUp() public override {
        super.setUp();
        detf = _deployOpenThresholdDetfN(1);
        detfInfo = IMixedBufferMultiVaultStableDetfInfo(detf);
        detfBonding = IMixedBufferMultiVaultStableDetfBonding(detf);
        detfExchangeIn = IStandardExchangeIn(detf);
        _bootstrapDefault(detf, alice);
    }

    function test_bond_buffer_after_live() public {
        _fundBuffer(bob, 100e18);
        vm.startPrank(bob);
        IERC20(address(dai)).approve(detf, 100e18);
        (uint256 tokenId_, uint256 principal_) = detfBonding.bond(
            IERC20(address(dai)), 100e18, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        assertTrue(tokenId_ > 0 && principal_ > 0, "buffer bond");
    }

    function test_bond_vaultShare_after_live() public {
        uint256 shares_ = _fundVaultShares(0, bob, 100e18);
        vm.startPrank(bob);
        seShares[0].approve(detf, shares_);
        (uint256 tokenId_, uint256 principal_) = detfBonding.bond(
            seShares[0], shares_, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        assertTrue(tokenId_ > 0 && principal_ > 0, "share bond");
    }

    function test_bond_reserveBpt_after_live() public {
        // Production path: user obtains reserve BPT via seRouter unbalanced join, then bonds BPT.
        uint256 bpt_ = _fundReserveBpt(detf, bob, 80e18);
        assertTrue(bpt_ > 0, "user funded with BPT");
        address pool_ = detfInfo.reservePool();
        assertEq(IERC20(pool_).balanceOf(bob), bpt_, "bob holds all funded BPT");

        vm.startPrank(bob);
        IERC20(pool_).approve(detf, bpt_);
        (uint256 tokenId_, uint256 principal_) = detfBonding.bond(
            IERC20(pool_), bpt_, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();

        assertTrue(tokenId_ > 0, "bpt bond nft");
        assertEq(principal_, bpt_, "principal == bpt bonded");
        assertEq(IERC20(pool_).balanceOf(bob), 0, "bpt pulled from bob");
    }

    function test_bond_lock_too_short_reverts() public {
        _fundBuffer(bob, 50e18);
        vm.startPrank(bob);
        IERC20(address(dai)).approve(detf, 50e18);
        vm.expectRevert();
        detfBonding.bond(
            IERC20(address(dai)), 50e18, 1 days, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
    }

    function test_bond_lock_clamps_to_max() public {
        _fundBuffer(bob, 50e18);
        vm.startPrank(bob);
        IERC20(address(dai)).approve(detf, 50e18);
        (uint256 tokenId_,) = detfBonding.bond(
            IERC20(address(dai)), 50e18, DEFAULT_MAX_LOCK + 365 days, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        assertTrue(tokenId_ > 0, "clamped lock succeeds");
    }

    function test_sellPositionToDetfNft_revertsBondNotMature() public {
        _fundBuffer(bob, 80e18);
        vm.startPrank(bob);
        IERC20(address(dai)).approve(detf, 80e18);
        (uint256 tokenId_,) = detfBonding.bond(
            IERC20(address(dai)), 80e18, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        uint256 unlock_ = IDETFNFTVault(detfInfo.bondNftVault()).unlockTimeOf(tokenId_);
        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSelector(bytes4(keccak256("BondNotMature(uint256)")), unlock_));
        detfBonding.sellPositionToDetfNft(tokenId_, 0, bob);
    }

    function test_sellPositionToDetfNft_afterMaturity_mints4626() public {
        _fundBuffer(bob, 80e18);
        vm.startPrank(bob);
        IERC20(address(dai)).approve(detf, 80e18);
        (uint256 tokenId_,) = detfBonding.bond(
            IERC20(address(dai)), 80e18, DEFAULT_MIN_LOCK, bob, false, block.timestamp + 1 hours
        );
        vm.stopPrank();
        _warpPastUnlock(detf, tokenId_);
        uint256 protocolBefore_ = detfBonding.protocolBondOriginalShares();
        vm.prank(bob);
        uint256 claimMinted_ = detfBonding.sellPositionToDetfNft(tokenId_, 0, bob);
        assertTrue(claimMinted_ > 0, "claim minted");
        uint256 protocolId_ = IDETFNFTVault(detfInfo.bondNftVault()).detfNFTId();
        assertEq(
            IDETFNFTVault(detfInfo.bondNftVault()).effectiveSharesOf(protocolId_),
            IDETFNFTVault(detfInfo.bondNftVault()).originalSharesOf(protocolId_),
            "1:1 protocol nft"
        );
        assertTrue(
            IDETFNFTVault(detfInfo.bondNftVault()).originalSharesOf(protocolId_) > protocolBefore_,
            "protocol credited"
        );
    }
}
