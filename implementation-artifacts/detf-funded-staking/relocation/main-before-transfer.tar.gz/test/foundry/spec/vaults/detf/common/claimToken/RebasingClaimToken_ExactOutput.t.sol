// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {UniswapV4SingleStandardExchangeBufferConstantProductHookMath as CpMath} from "contracts/hooks/uniswap/v4/standardExchange/constantProduct/single/UniswapV4SingleStandardExchangeBufferConstantProductHookMath.sol";
import {IERC20} from "@crane/contracts/interfaces/IERC20.sol";
import {IRebasingClaimToken} from "contracts/interfaces/IRebasingClaimToken.sol";
import {IDetfErrors} from "contracts/interfaces/IDetfErrors.sol";
import {IUniswapV4Detf} from
    "contracts/vaults/detf/protocols/dexes/uniswap/v4/detf/interfaces/IUniswapV4Detf.sol";
import {UniswapV4Detf_ClaimBase} from
    "test/foundry/spec/vaults/detf/protocols/dexes/uniswap/v4/detf/UniswapV4Detf_ClaimBase.sol";

// tag::RebasingClaimToken_ExactOutput[]
/// @notice Exact-output exchange consumes rebasing balances at non-unit rates.
/// @dev Production DETF, hook, NFT and claim proxies use the inherited registry
///      deployment. The existing owner-mediated sale helper seeds claim ownership;
///      every exchange under test is called by the ordinary claim holder.
contract RebasingClaimToken_ExactOutput is UniswapV4Detf_ClaimBase {
    function test_largeReserve_zapSplit_matchesIndependentIntegerRoots() public pure {
        // Roots evaluated independently with arbitrary-precision integer square roots.
        assertEq(CpMath.swapDepositSaleAmt(1e38, 1e39), 48_882_173_994_193_580_692_720_962_042_048_031_728);
        assertEq(CpMath.swapDepositSaleAmt(1e33, 1e12), 31_670_317_759_975_314_128_799);
        assertEq(
            CpMath.swapDepositSaleAmt(1_468_412_954_698_849_018_164_308_302_468_434, 1_039_960_158_295_632_572_962_576_340_945_594_816_728),
            735_309_181_950_135_285_813_052_533_171_955
        );
    }

    function test_exactOutput_coarseReserveLp_matchesPreviewAndMinimalInput() public {
        IUniswapV4Detf.PkgArgs memory args_ = _defaultDetfArgs();
        args_.creationPairPerDetfWad[0] = 1;
        address instance_ = _deployTagged(args_, "claim-coarse-reserve-lp");
        _firstBondOn(instance_, 1000 ether);
        (uint256 tokenId_,) = _bondOn(instance_, detfUser, 40 ether);
        _warpMatureOf(instance_, tokenId_);
        _d10SellToClaimOn(instance_, tokenId_, detfUser);
        IRebasingClaimToken claim_ = _claimTokOf(instance_);
        assertGt(claim_.redemptionRate(), 1e24, "one LP wei has material DETF value");
        _assertPreviewBoundaries(instance_, claim_);
        _assertExactOutput(instance_, claim_);
    }

    /// @notice A rate above one must not divide the claim balance input by the rate again.
    function test_exactOutput_aboveUnitRate_executesQuotedInput() public {
        (address instance_, IRebasingClaimToken claim_) = _claimAtRate(false);
        _assertExactOutput(instance_, claim_);
    }

    /// @notice A rate below one must not over-consume the holder's rebasing balance.
    function test_exactOutput_belowUnitRate_executesQuotedInput() public {
        (address instance_, IRebasingClaimToken claim_) = _claimAtRate(true);
        _assertExactOutput(instance_, claim_);
    }

    /// @notice Too-small maximum input atomically preserves both claim and reserve accounting.
    function test_exactOutput_aboveUnitRate_maxInputProtectsHolder() public {
        (address instance_, IRebasingClaimToken claim_) = _claimAtRate(false);
        _assertMaxInput(instance_, claim_);
    }

    /// @notice Maximum input is enforced in token-balance units below a unit rate too.
    function test_exactOutput_belowUnitRate_maxInputProtectsHolder() public {
        (address instance_, IRebasingClaimToken claim_) = _claimAtRate(true);
        _assertMaxInput(instance_, claim_);
    }

    /// @notice Upward rounding must invert the two floor operations at tiny output boundaries.
    function test_exactOutput_aboveUnitRate_previewIsMinimalAtRoundingBoundaries() public {
        (address instance_, IRebasingClaimToken claim_) = _claimAtRate(false);
        _assertPreviewBoundaries(instance_, claim_);
    }

    /// @notice Tiny exact-output quotes remain minimal with more than one share per balance unit.
    function test_exactOutput_belowUnitRate_previewIsMinimalAtRoundingBoundaries() public {
        (address instance_, IRebasingClaimToken claim_) = _claimAtRate(true);
        _assertPreviewBoundaries(instance_, claim_);
    }

    function _claimAtRate(bool belowUnit_) private returns (address instance_, IRebasingClaimToken claim_) {
        IUniswapV4Detf.PkgArgs memory args_ = _defaultDetfArgs();
        // CP LP units depend on sqrt(pair * DETF). The creation ratio changes
        // DETF value per LP unit without manipulating contract storage or quotes.
        args_.creationPairPerDetfWad[0] = belowUnit_ ? 100e18 : 1e18;
        instance_ = _deployTagged(args_, belowUnit_ ? "claim-rate-low" : "claim-rate-high");
        _firstBondOn(instance_, 1000 ether);
        (uint256 tokenId_,) = _bondOn(instance_, detfUser, 40 ether);
        _warpMatureOf(instance_, tokenId_);
        (, uint256 minted_) = _d10SellToClaimOn(instance_, tokenId_, detfUser);
        assertGt(minted_, 0, "production sale creates claims");
        claim_ = _claimTokOf(instance_);
        assertEq(address(claim_.rateAsset()), instance_, "advertised claim output is DETF (D15)");
        if (belowUnit_) {
            assertLt(claim_.redemptionRate(), 0.9e18, "fixture rate materially below one");
        } else {
            assertGt(claim_.redemptionRate(), 1.1e18, "fixture rate materially above one");
        }
    }

    function _assertExactOutput(address instance_, IRebasingClaimToken claim_) private {
        IERC20 input_ = IERC20(address(claim_));
        IERC20 output_ = IERC20(instance_);
        uint256 target_ = claim_.balanceOf(detfUser) / 1000;
        uint256 quoted_ = claim_.previewExchangeOut(input_, output_, target_);
        uint256 preview_ = claim_.previewExchangeIn(input_, quoted_, output_);
        assertGe(preview_, target_, "quoted balance covers exact output");
        assertLt(claim_.previewExchangeIn(input_, quoted_ - 1, output_), target_, "one less cannot cover output");
        uint256 sharesBefore_ = claim_.sharesOf(detfUser);
        uint256 sharesConsumed_ = claim_.convertToShares(quoted_);
        address recipient_ = makeAddr("exact-output-recipient");
        uint256 before_ = output_.balanceOf(recipient_);

        vm.prank(detfUser);
        uint256 used_ = claim_.exchangeOut(
            input_, quoted_, output_, target_, recipient_, false, block.timestamp + 1 hours
        );

        assertEq(used_, quoted_, "execution consumes quoted rebasing amount");
        assertEq(output_.balanceOf(recipient_) - before_, preview_, "payout matches redeem preview");
        assertApproxEqAbs(
            sharesBefore_ - claim_.sharesOf(detfUser), sharesConsumed_, 1, "only quoted input shares burned"
        );
    }

    function _assertMaxInput(address instance_, IRebasingClaimToken claim_) private {
        IERC20 input_ = IERC20(address(claim_));
        IERC20 output_ = IERC20(instance_);
        uint256 target_ = claim_.balanceOf(detfUser) / 1000;
        uint256 quoted_ = claim_.previewExchangeOut(input_, output_, target_);
        uint256 sharesBefore_ = claim_.sharesOf(detfUser);
        uint256 totalBefore_ = claim_.totalShares();
        uint256 principalBefore_ = _nftOf(instance_).originalSharesOf(0);
        uint256 lpBefore_ = _lpOf(instance_).balanceOf(address(_nftOf(instance_)));
        uint256 outputBefore_ = output_.balanceOf(detfUser);

        vm.prank(detfUser);
        vm.expectRevert(abi.encodeWithSelector(IDetfErrors.SlippageExceeded.selector, quoted_ - 1, quoted_));
        claim_.exchangeOut(input_, quoted_ - 1, output_, target_, detfUser, false, block.timestamp + 1 hours);

        assertEq(claim_.sharesOf(detfUser), sharesBefore_, "holder shares unchanged");
        assertEq(claim_.totalShares(), totalBefore_, "total shares unchanged");
        assertEq(_nftOf(instance_).originalSharesOf(0), principalBefore_, "protocol principal unchanged");
        assertEq(_lpOf(instance_).balanceOf(address(_nftOf(instance_))), lpBefore_, "LP custody unchanged");
        assertEq(output_.balanceOf(detfUser), outputBefore_, "no payout on failed maximum");
    }

    function _assertPreviewBoundaries(address instance_, IRebasingClaimToken claim_) private view {
        IERC20 input_ = IERC20(address(claim_));
        IERC20 output_ = IERC20(instance_);
        assertEq(claim_.previewExchangeOut(input_, output_, 0), 0, "zero output quote");
        for (uint256 target_ = 1; target_ <= 32; ++target_) {
            uint256 quoted_ = claim_.previewExchangeOut(input_, output_, target_);
            assertGe(claim_.previewExchangeIn(input_, quoted_, output_), target_, "rounded input sufficient");
            assertLt(claim_.previewExchangeIn(input_, quoted_ - 1, output_), target_, "rounded input minimal");
        }
    }
}
// end::RebasingClaimToken_ExactOutput[]
