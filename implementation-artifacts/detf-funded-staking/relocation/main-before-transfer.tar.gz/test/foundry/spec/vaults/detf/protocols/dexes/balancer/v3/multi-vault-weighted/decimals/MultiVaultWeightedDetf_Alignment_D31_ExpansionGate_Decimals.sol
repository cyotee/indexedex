// SPDX-License-Identifier: BSL-1.1
pragma solidity ^0.8.0;

import {TestBase_MultiVaultWeightedDetf_Decimals} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/TestBase_MultiVaultWeightedDetf_Decimals.sol";

import {ThresholdMode} from "contracts/vaults/detf/common/core/DETFThresholdPolicy.sol";
import {
    IMultiVaultWeightedDetfInfo
} from "contracts/vaults/detf/protocols/dexes/balancer/v3/multi-vault-weighted/MultiVaultWeightedDetfInfoTarget.sol";

abstract contract MultiVaultWeightedDetf_Alignment_D31_ExpansionGate_Decimals is TestBase_MultiVaultWeightedDetf_Decimals {
    function test_D31_4_openDoesNotExpandOnCompound() public {
        detf = _deployOpenModeDetf("D31 MVW", "d31mvw");
        detfInfo = IMultiVaultWeightedDetfInfo(detf);
        _bootstrapViaFirstBond(alice, 1_000e18);
        uint256 last_ = detfInfo.lastExpansionTimestamp();
        vm.warp(block.timestamp + 30 days);
        assertEq(uint8(detfInfo.thresholdMode()), uint8(ThresholdMode.Open));
        assertEq(detfInfo.lastExpansionTimestamp(), last_, "D31-4");
    }
}
